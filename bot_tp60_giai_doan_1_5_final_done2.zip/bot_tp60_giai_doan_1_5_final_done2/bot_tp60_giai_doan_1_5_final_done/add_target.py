import pandas as pd

df = pd.read_csv('ethusdt_15m_with_indicators.csv')

TP = 0.01  # 1% take profit
SL = 0.01  # 1% stop loss
forward = 5  # số nến kiểm tra

target_long = []
target_short = []

for i in range(len(df) - forward):
    entry = df['close'].iloc[i]
    highs = df['high'].iloc[i+1:i+1+forward]
    lows = df['low'].iloc[i+1:i+1+forward]
    # target_long: 1 nếu có nến nào lên trên entry + TP% trước khi chạm xuống entry - SL%
    hit_tp_long = (highs >= entry * (1 + TP)).any()
    hit_sl_long = (lows <= entry * (1 - SL)).any()
    target_long.append(int(hit_tp_long and not hit_sl_long))
    # target_short: 1 nếu có nến nào xuống dưới entry - TP% trước khi chạm lên entry + SL%
    hit_tp_short = (lows <= entry * (1 - TP)).any()
    hit_sl_short = (highs >= entry * (1 + SL)).any()
    target_short.append(int(hit_tp_short and not hit_sl_short))

# Do vòng lặp bỏ forward nến cuối, ta nối thêm 0 cho bằng độ dài dataframe
while len(target_long) < len(df):
    target_long.append(0)
    target_short.append(0)

df['target_long'] = target_long
df['target_short'] = target_short

df.to_csv('ethusdt_15m_ready.csv', index=False)
print("Đã tạo cột target cho file: ethusdt_15m_ready.csv")
