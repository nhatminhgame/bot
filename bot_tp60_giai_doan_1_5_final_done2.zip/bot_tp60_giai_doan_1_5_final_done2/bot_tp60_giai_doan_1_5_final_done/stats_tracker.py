
import os
import json
from datetime import datetime, timedelta

STATS_FILE = "strategy_stats.json"
SUSPENDED_FILE = "suspended_groups.json"

def load_stats():
    if not os.path.exists(STATS_FILE):
        return []
    with open(STATS_FILE, "r") as f:
        return json.load(f)

def save_stats(data):
    with open(STATS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def record_result(group, result, coin):
    stats = load_stats()
    stats.append({
        "time": datetime.utcnow().isoformat(),
        "group": group,
        "result": result,
        "coin": coin
    })
    save_stats(stats)

def evaluate_winrate(days=10, threshold=0.45):
    stats = load_stats()
    cutoff = datetime.utcnow() - timedelta(days=days)
    group_results = {}
    for entry in stats:
        entry_time = datetime.fromisoformat(entry["time"])
        if entry_time >= cutoff:
            group = entry["group"]
            if group not in group_results:
                group_results[group] = {"TP": 0, "SL": 0}
            group_results[group][entry["result"]] += 1

    suspended = []
    for group, res in group_results.items():
        total = res["TP"] + res["SL"]
        winrate = res["TP"] / total if total > 0 else 0
        if winrate < threshold:
            suspended.append(group)

    with open(SUSPENDED_FILE, "w") as f:
        json.dump(suspended, f)

    return suspended, group_results
