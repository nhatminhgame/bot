import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
import joblib

# Tải dữ liệu CSV đã chuẩn hóa
df = pd.read_csv("multi_coin_15m_1year.csv")

# Chỉ lấy dữ liệu ETH để fine-tune
df_eth = df[df["symbol"] == "ETH/USDT"].copy()
df_eth = df_eth.dropna()

# Chọn feature và target
features = [
    'volume', 'volatility_bbm', 'trend_macd', 'momentum_rsi',
    'trend_ema_fast', 'trend_ema_slow', 'trend_adx', 'volatility_atr',
    'momentum_wr', 'momentum_ao', 'trend_kst', 'trend_ichimoku_base_line'
]
X = df_eth[features]
y = df_eth['target']

# Chia train/test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Huấn luyện mô hình
model = lgb.LGBMClassifier(n_estimators=200, learning_rate=0.05)
model.fit(X_train, y_train)

# Đánh giá
y_pred = model.predict_proba(X_test)[:, 1]
auc = roc_auc_score(y_test, y_pred)
print(f"AUC ETH model: {auc:.4f}")

# Lưu mô hình
joblib.dump(model, "model_eth_optimized.pkl")
print("✅ Đã lưu model_eth_optimized.pkl")
