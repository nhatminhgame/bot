
# trailing.py
def update_trailing_sl(entry_price, current_price, atr, prev_trailing_sl, direction='long'):
    if direction == 'long':
        new_trailing = current_price - 0.3 * atr
        return max(prev_trailing_sl, new_trailing)
    else:
        new_trailing = current_price + 0.3 * atr
        return min(prev_trailing_sl, new_trailing)
