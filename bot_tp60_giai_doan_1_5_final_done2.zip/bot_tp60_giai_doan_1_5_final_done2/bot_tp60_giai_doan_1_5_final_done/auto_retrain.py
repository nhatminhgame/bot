
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
import joblib

def retrain_ai_model():
    print("Retraining AI model...")
    df = pd.read_csv("ethusdt_15m.csv")
    df = df.dropna()
    X = df.drop(columns=["target"])
    y = df["target"]

    X_train, _, y_train, _ = train_test_split(X, y, test_size=0.2, random_state=42)
    model = lgb.LGBMClassifier(n_estimators=150, learning_rate=0.05)
    model.fit(X_train, y_train)

    joblib.dump(model, "model_lgb_optimized.pkl")
    print("✅ Retraining complete, model saved as model_lgb_optimized.pkl")

if __name__ == "__main__":
    retrain_ai_model()
