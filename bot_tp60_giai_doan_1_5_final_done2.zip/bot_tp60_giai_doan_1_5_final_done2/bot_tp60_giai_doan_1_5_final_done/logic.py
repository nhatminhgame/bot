import joblib
import pandas as pd

# Load model
model = joblib.load("models/model_ethusdt_long.pkl")

# Load dữ liệu
df = pd.read_csv("ethusdt_15m_with_indicators.csv")

# Danh sách feature đúng như bạn cung cấp
features = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal',
    'adx', 'atr', 'ema_fast', 'ema_slow', 'volatility_bbh',
    'momentum_wr', 'trend_macd', 'trend_kst',
    'momentum_ao', 'trend_ichimoku_base', 'trend_adx'
]

# Lọc dòng cuối cùng
x = df[features].dropna().iloc[-1:]
prob = model.predict_proba(x)[0][1]
print("✅ AI TP Long:", round(prob * 100, 2), "%")
