import pandas as pd
from indicators import get_all_indicators
from ai_predict import predict_prob
from config import config

# Đọc dữ liệu lịch sử
df = pd.read_csv("ETHUSDT_15m.csv")  # Thay bằng file nến bạn có (OHLCV)

indicators = get_all_indicators(df)
results = []
capital = 1000  # giả định vốn ban đầu
position = 0
entry_price = 0
win = 0
loss = 0
total_pnl = 0

for i in range(config['lookback'], len(indicators)):
    X = indicators.iloc[[i]].copy()
    win_prob = predict_prob(X)
    price = df['close'].iloc[i]

    if position == 0:
        if win_prob > config['ai_threshold']:
            side = 'long' if win_prob > 0.5 else 'short'
            entry_price = price
            position = 1 if side == 'long' else -1
            tp = entry_price * (1 + config['rr_ratio']/100) if side == 'long' else entry_price * (1 - config['rr_ratio']/100)
            sl = entry_price * (1 - config['rr_ratio']/100) if side == 'long' else entry_price * (1 + config['rr_ratio']/100)
            entry_idx = i
    else:
        # Kiểm tra TP/SL trong 1 khoảng lookahead (ví dụ 10 nến tiếp)
        reached_tp, reached_sl = False, False
        lookahead = 10
        for j in range(i, min(i + lookahead, len(df))):
            high = df['high'].iloc[j]
            low = df['low'].iloc[j]
            if position == 1 and high >= tp:
                pnl = tp - entry_price
                reached_tp = True
                win += 1
                total_pnl += pnl
                results.append({'type': 'win', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
                position = 0
                break
            if position == 1 and low <= sl:
                pnl = sl - entry_price
                reached_sl = True
                loss += 1
                total_pnl += pnl
                results.append({'type': 'loss', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
                position = 0
                break
            if position == -1 and low <= tp:
                pnl = entry_price - tp
                reached_tp = True
                win += 1
                total_pnl += pnl
                results.append({'type': 'win', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
                position = 0
                break
            if position == -1 and high >= sl:
                pnl = entry_price - sl
                reached_sl = True
                loss += 1
                total_pnl += pnl
                results.append({'type': 'loss', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
                position = 0
                break
        if not reached_tp and not reached_sl and j == min(i + lookahead, len(df)) - 1:
            # Hết lookahead, close tại giá cuối
            pnl = (df['close'].iloc[j] - entry_price) * position
            if pnl > 0:
                win += 1
                results.append({'type': 'win', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
            else:
                loss += 1
                results.append({'type': 'loss', 'pnl': pnl, 'entry_idx': entry_idx, 'exit_idx': j})
            total_pnl += pnl
            position = 0

print("Tổng số lệnh:", win + loss)
print("Win:", win, "Loss:", loss)
print("Winrate:", win / (win + loss) if (win + loss) > 0 else 0)
print("Tổng PnL:", total_pnl)
