
def is_bb_squeeze(df):
    bb_width = df['upper_bb'] - df['lower_bb']
    return bb_width.iloc[-1] < bb_width.rolling(20).mean().iloc[-1] * 0.8

def is_macd_histogram_rising(df):
    hist = df['macd_histogram']
    return hist.iloc[-1] > hist.iloc[-2] > hist.iloc[-3]

def is_bullish_big_body_breakout_candle(df):
    last = df.iloc[-1]
    body = abs(last['close'] - last['open'])
    range_ = last['high'] - last['low']
    return last['close'] > last['open'] and body > 0.7 * range_

def evaluate_early_long_entry(df):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]
    volume = df['volume'].iloc[-1]
    ma_volume20 = df['volume'].rolling(20).mean().iloc[-1]

    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if volume > 1.5 * ma_volume20:
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1

    return score >= 3


def is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
    """Xác nhận xu hướng tăng bằng EMA crossover"""
    return df[short_ema].iloc[-1] > df[long_ema].iloc[-1] and df[short_ema].iloc[-2] > df[long_ema].iloc[-2]

def is_volume_spike(df, multiplier=1.5):
    """Kiểm tra volume hiện tại lớn hơn x lần volume trung bình 20 nến"""
    vol = df['volume'].iloc[-1]
    ma_vol = df['volume'].rolling(20).mean().iloc[-1]
    return vol > multiplier * ma_vol

def evaluate_early_long_entry(df):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]
    volume = df['volume'].iloc[-1]
    ma_volume20 = df['volume'].rolling(20).mean().iloc[-1]

    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    return score >= 4  # nâng ngưỡng để lọc tín hiệu yếu


import joblib
import pandas as pd

# Load model AI trend (nếu chưa load ở nơi khác)
try:
    model_trend = joblib.load("model_trend_predictor.pkl")
except:
    model_trend = None

def get_trend_prediction(df):
    if model_trend is None:
        return "UNKNOWN"
    features = df.select_dtypes(include=["number"]).dropna().iloc[-1:]
    pred_class = model_trend.predict(features)[0]
    if pred_class == 0:
        return "DOWN"
    elif pred_class == 1:
        return "SIDEWAY"
    else:
        return "UP"

def evaluate_early_long_entry(df):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]

    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    trend = get_trend_prediction(df)
    if trend == "UP":
        score += 1

    return score >= 5


def evaluate_signal_cluster(df):
    """Đánh giá cụm tín hiệu kỹ thuật đồng thuận: EMA trend, MACD histogram, Volume spike"""
    score = 0
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    return score >= 2  # yêu cầu ít nhất 2 trong 3 tín hiệu đồng thời


# Load AI entry regressor model nếu có
try:
    import joblib
    model_entry = joblib.load("model_entry_regressor.pkl")
except:
    model_entry = None

def predict_entry_offset(df):
    """Dự đoán khoảng cách limit tối ưu tính từ giá hiện tại (âm là dưới giá hiện tại)"""
    if model_entry is None:
        return -0.0025  # fallback mặc định -0.25%
    X = df.select_dtypes(include=["number"]).dropna().iloc[-1:]
    pred_offset = model_entry.predict(X)[0]
    return float(pred_offset)


MODE = "balanced"  # Options: conservative, balanced, aggressive

def evaluate_early_long_entry(df, ai_tp=0.0):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]

    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    # Entry logic theo chế độ
    if MODE == "conservative":
        return score >= 5 and ai_tp >= 70
    elif MODE == "balanced":
        return score >= 3 and ai_tp >= 68
    elif MODE == "aggressive":
        return score >= 2 and ai_tp >= 65
    return False


# ⚙️ Logic vào lệnh đã nới điều kiện theo yêu cầu thực tế
MODE = "balanced"  # Options: conservative, balanced, aggressive

def evaluate_early_long_entry(df, ai_tp=0.0):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]

    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    # Logic chế độ vào lệnh mở rộng
    if MODE == "conservative":
        return score >= 5 and ai_tp >= 70
    elif MODE == "balanced":
        return score >= 3 and ai_tp >= 65
    elif MODE == "aggressive":
        return score >= 2 and ai_tp >= 60
    return False


MODE = "balanced"  # Options: conservative, balanced, aggressive

def evaluate_early_long_entry(df, ai_tp=0.0, ai_trend="UP"):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]

    # Tính điểm kỹ thuật
    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    # Điều kiện phụ hỗ trợ nếu TP >= 60%
    support_signal = 0
    if is_volume_spike(df, multiplier=2.0):
        support_signal += 1
    if ai_trend.upper() == "UP":
        support_signal += 1

    if MODE == "conservative":
        return score >= 5 and ai_tp >= 70
    elif MODE == "balanced":
        if ai_tp >= 65 and score >= 3:
            return True
        elif ai_tp >= 60 and score >= 3 and support_signal >= 1:
            return True
        else:
            return False
    elif MODE == "aggressive":
        return score >= 2 and ai_tp >= 60
    return False


# ⚙️ Logic mở rộng thêm cho Early Entry
def evaluate_early_long_entry(df, ai_tp=0.0, ai_trend="UP", entry_type="early"):
    score = 0
    close = df['close'].iloc[-1]
    upper_bb = df['upper_bb'].iloc[-1]
    ma20 = df['ma20'].iloc[-1]

    # Tín hiệu kỹ thuật chính
    if is_bb_squeeze(df) and close > upper_bb:
        score += 1
    if is_macd_histogram_rising(df):
        score += 1
    if close > ma20 and df['close'].iloc[-2] > ma20:
        score += 1
    if is_volume_spike(df, multiplier=1.5):
        score += 1
    if is_bullish_big_body_breakout_candle(df):
        score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        score += 1

    # Điều kiện phụ hỗ trợ nếu TP thấp
    support_signal = 0
    if is_volume_spike(df, multiplier=2.0):
        support_signal += 1
    if ai_trend.upper() == "UP":
        support_signal += 1

    # Xử lý theo loại entry
    if entry_type == "early":
        if ai_tp >= 65 and score >= 3:
            return True
        elif ai_tp >= 58 and score >= 4:
            return True
        else:
            return False
    else:  # confirm entry
        if ai_tp >= 65 and score >= 3:
            return True
        elif ai_tp >= 60 and score >= 3 and support_signal >= 1:
            return True
        else:
            return False


# Smart Weighted Entry System
# Vào lệnh nếu tổng điểm từ các nhóm AI + kỹ thuật + tình huống ≥ ngưỡng cho phép

SMART_ENTRY_THRESHOLD = 7  # tổng điểm tối thiểu để vào lệnh

def evaluate_smart_entry(df, ai_tp=0.0, ai_trend="UP", entry_type="early"):
    total_score = 0

    # Nhóm 1: AI (max 3 điểm)
    if ai_tp >= 70:
        total_score += 3
    elif ai_tp >= 65:
        total_score += 2
    elif ai_tp >= 60:
        total_score += 1

    if ai_trend.upper() == "UP":
        total_score += 1  # trend đúng hướng (max AI nhóm này: 3)

    # Nhóm 2: Kỹ thuật (max 6 điểm)
    if is_bb_squeeze(df) and df['close'].iloc[-1] > df['upper_bb'].iloc[-1]:
        total_score += 1
    if is_macd_histogram_rising(df):
        total_score += 1
    if df['close'].iloc[-1] > df['ma20'].iloc[-1] and df['close'].iloc[-2] > df['ma20'].iloc[-2]:
        total_score += 1
    if is_ema_trending(df, short_ema='ema9', long_ema='ema21'):
        total_score += 1
    if is_volume_spike(df, multiplier=1.5):
        total_score += 1
    if is_bullish_big_body_breakout_candle(df):
        total_score += 1

    # Nhóm 3: Tình huống đặc biệt (max 2 điểm)
    if detect_spring_entry(df):
        total_score += 2  # override mạnh
    elif is_volume_spike(df, multiplier=2.0):
        total_score += 1
    elif df['close'].iloc[-1] > df['high'].rolling(10).max().iloc[-2]:
        total_score += 1  # breakout xác nhận

    return total_score >= SMART_ENTRY_THRESHOLD
