import pandas as pd
import lightgbm as lgb
import joblib
import os

# Doc du lieu tu file CSV
df = pd.read_csv("multi_coin_15m_1year.csv")

# Danh sach cac dong coin can huan luyen
danh_sach_coin = [
    'BTC/USDT', 'ETH/USDT', 'ADA/USDT', 'AVAX/USDT',
    'BNB/USDT', 'DOGE/USDT', 'LTC/USDT', 'SOL/USDT', 'XRP/USDT'
]

# Cac cot khong dung de train
bo_qua = ['timestamp', 'symbol', 'coin_id', 'future_return', 'target_long', 'target_short']
os.makedirs("models", exist_ok=True)

# Lap qua tung dong coin
for coin in danh_sach_coin:
    print(f"🔄 Dang huan luyen {coin}...")
    du_lieu = df[df['symbol'] == coin].dropna()

    if du_lieu.empty:
        print(f"⚠️ Khong co du lieu cho {coin}, bo qua.")
        continue

    X = du_lieu[[cot for cot in du_lieu.columns if cot not in bo_qua]]
    y_long = du_lieu['target_long']
    y_short = du_lieu['target_short']

    # Train mo hinh long
    model_long = lgb.LGBMClassifier(n_estimators=100, random_state=42)
    model_long.fit(X, y_long)
    joblib.dump(model_long, f"models/model_{coin.replace('/', '').lower()}_long.pkl")

    # Train mo hinh short
    model_short = lgb.LGBMClassifier(n_estimators=100, random_state=42)
    model_short.fit(X, y_short)
    joblib.dump(model_short, f"models/model_{coin.replace('/', '').lower()}_short.pkl")

print("✅ Hoan tat huan luyen tat ca mo hinh.")
