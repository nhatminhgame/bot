import pandas as pd
import joblib

# Load model
model_risk = joblib.load("models/model_risk_classifier.pkl")
model_breakout = joblib.load("models/model_breakout_classifier.pkl")

# Đọc dữ liệu
df = pd.read_csv("ethusdt_15m_with_indicators.csv").dropna()

# Danh sách 33 feature chuẩn
FEATURE_COLUMNS = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal', 'adx', 'atr', 'ema_fast', 'ema_slow',
    'volatility_bbh', 'momentum_wr', 'trend_macd', 'trend_kst', 'momentum_ao',
    'trend_ichimoku_base', 'trend_adx', 'ema_distance', 'macd_histogram', 'atr_change',
    'wick_ratio', 'price_change_3', 'price_change_10', 'ema_fast_slope', 'bb_pos',
    'volume_change', 'rsi_slope', 'macd_cross', 'volatility_ratio',
    'rsi_1h', 'ema_1h', 'macd_1h', 'macd_signal_1h', 'volume_change_1h'
]

# Chuẩn bị dữ liệu
X_risk = df[FEATURE_COLUMNS].tail(5)
X_breakout = X_risk.iloc[:, :28]  # breakout dùng 28 feature đầu

# Dự đoán
risk_probs = model_risk.predict_proba(X_risk)[:, 1]
breakout_probs = model_breakout.predict_proba(X_breakout)[:, 1]

# In kết quả
for i in range(len(risk_probs)):
    print(f"\n✅ Sample {i+1}:")
    print(f"• Risk Prob: {risk_probs[i]*100:.2f}%", "→ PASS ✅" if risk_probs[i] > 0.55 else "→ FAIL ❌")
    print(f"• Breakout Prob: {breakout_probs[i]*100:.2f}%", "→ PASS ✅" if breakout_probs[i] > 0.55 else "→ FAIL ❌")
