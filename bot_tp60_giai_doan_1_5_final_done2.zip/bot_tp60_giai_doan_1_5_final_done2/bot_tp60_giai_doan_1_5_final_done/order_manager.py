
# order_manager.py - Full version with LIMIT DCA, trailing, close_position, evaluate_risk

import time
from datetime import datetime
from config import config
from telegram_notify import send_telegram_message
from log_trade import log_trade

class OrderManager:

    def ensure_dual_position_mode(self):
        try:
            mode = self.exchange.fapiPrivateGetAccount()['dualSidePosition']
            if not mode:
                self.exchange.fapiPrivate_post_positionside_dual({'dualSidePosition': True})
                print("✅ Đã bật chế độ dualSidePosition cho Futures")
        except Exception as e:
            print(f"[ERROR] Kiểm tra dualSidePosition thất bại: {e}")

    def __init__(self, config):
        self.exchange = config['exchange']
        print("✅ Endpoint dang dung:", self.exchange.urls["api"])
        self.symbol = config['symbol']
        self.leverage = config.get('leverage', 4)
        self.position_data = {}
        self.limit_orders = []

    def has_open_position(self):
        print("[DEBUG] ✅ dang dùng has_open_position moi")
        positions = self.exchange.fetch_positions()
        for p in positions:
            if p['symbol'] == self.symbol.replace("/", "") and float(p['positionAmt']) != 0:
                return True
        return False

    def evaluate_risk(self, indicators):
        adx = indicators['adx'].iloc[-1]
        volume = indicators['volume'].iloc[-1]
        trend = indicators['trend'].iloc[-1] if 'trend' in indicators.columns else 0

        if adx > 25 and volume > indicators['volume'].mean():
            return "LOW"
        elif adx > 20:
            return "MEDIUM"
        return "HIGH"

    def place_order_limit_dca(self, side, size, base_price, offsets=[0.001, 0.0025, 0.004]):
        side_str = "BUY" if side == "long" else "SELL"
        for offset in offsets:
            entry_price = base_price * (1 - offset) if side == "long" else base_price * (1 + offset)
            order = self.exchange.create_order(
                symbol=self.symbol,
                type='LIMIT',
                side=side_str,
                amount=round(size / 3, 4),
                price=round(entry_price, 2),
                params={'timeInForce': 'GTC'}
            )
            self.limit_orders.append(order)
        send_telegram_message(f"[LIMIT DCA] Đã đặt 3 lệnh LIMIT {side.upper()} quanh giá {base_price:.2f}")

    def fallback_to_market(self, side, size, timeout=60):
        time.sleep(timeout)
        filled = any(self.has_open_position() for _ in range(3))
        if not filled:
            send_telegram_message("[FALLBACK] Hủy LIMIT DCA, vào lệnh MARKET")
            self.open_order(side, size)

    def open_order(self, side, size, df=None, custom_entry=None, custom_tp=None, custom_sl=None):
        price = custom_entry or df['close'].iloc[-1]
        side_str = "BUY" if side == "long" else "SELL"
        opposite = "SELL" if side == "long" else "BUY"

        self.exchange.create_order(symbol=self.symbol, type='MARKET', side=side_str, amount=size)

        tp_price = custom_tp or (price * 1.02 if side == "long" else price * 0.98)
        sl_price = custom_sl or (price * 0.985 if side == "long" else price * 1.015)

        self.exchange.create_order(symbol=self.symbol, type='LIMIT', side=opposite,
                                   amount=size, price=round(tp_price, 2),
                                   params={'reduceOnly': True, 'timeInForce': 'GTC'})

        self.exchange.create_order(symbol=self.symbol, type='STOP_MARKET', side=opposite,
                                   amount=size, stopPrice=round(sl_price, 2),
                                   params={'reduceOnly': True})

        self.position_data = {
            "side": side,
            "entry": price,
            "size": size,
            "tp1": price * 1.015 if side == "long" else price * 0.985,
            "trail_started": False
        }
        send_telegram_message(f"[VÀO LỆNH] {side.upper()} {size} @ {price:.2f} | TP: {tp_price:.2f} | SL: {sl_price:.2f}")
        log_trade(self.symbol, side, price, tp_price, sl_price, size)

    def manage_trailing_stop(self, current_price):
        if not self.position_data or self.position_data.get("trail_started"):
            return

        entry = self.position_data["entry"]
        side = self.position_data["side"]
        tp1 = self.position_data["tp1"]

        if (side == "long" and current_price >= tp1) or (side == "short" and current_price <= tp1):
            self.position_data["trail_started"] = True
            send_telegram_message(f"[TRAILING] Kích hoạt trailing sau TP1 đạt {tp1:.2f}")

    def close_position(self):        
        positions = self.exchange.fetch_positions()
        for p in positions:
            if p['symbol'] == self.symbol.replace("/", "") and float(p['positionAmt']) != 0:
                amt = abs(float(p['positionAmt']))
                side = "SELL" if float(p['positionAmt']) > 0 else "BUY"
                self.exchange.create_order(
                    symbol=self.symbol, type="MARKET", side=side,
                    amount=round(amt, 4), params={"reduceOnly": True}
                )
                send_telegram_message(f"[ĐÓNG LỆNH] Close vị thế {side} {amt}")

    def manage_positions(self, df, indicators, prob):
        print("[DEBUG] ✅ da chay phiên ban order_manager moi không dùng params")
        try:
            # Gia hien tai
            current_price = df["close"].iloc[-1]

            # Kiem tra trailing stop
            self.manage_trailing_stop(current_price)

            # Neu AI TP < 0.55 thi dong lenh som
            if prob < 0.55:
                self.close_position()
                send_telegram_message("[Bot] Dong lenh som do AI TP giam xuong < 55%")
        except Exception as e:
            send_telegram_message(f"[Bot] Loi trong manage_positions: {e}")




from trailing_stop import calculate_trailing_stop

def manage_trailing_stop(position, current_price, atr):
    """
    Quản lý trailing stop sau khi đạt TP1.
    Nếu đã đạt TP1, dời SL lên theo trailing logic.
    """
    if position.get("tp1_hit", False) and not position.get("sl_trailed", False):
        entry_price = position["entry"]
        new_sl = calculate_trailing_stop(entry_price, current_price, atr)
        position["stop_loss"] = new_sl
        position["sl_trailed"] = True
        print(f"[TRAILING STOP] Dời SL lên {new_sl} sau khi TP1 đạt.")
        return position
    return position


    def create_reduceonly_tp_sl(self, entry_price, side, atr, rr_ratio=1.5):
        sl_price = round(entry_price * (1 - 0.01), 2) if side == "long" else round(entry_price * (1 + 0.01), 2)
        tp_price = round(entry_price + atr * rr_ratio, 2) if side == "long" else round(entry_price - atr * rr_ratio, 2)

        params = {'reduceOnly': True}

        sl_order = self.exchange.create_order(
            symbol=self.symbol,
            type="STOP_MARKET",
            side="sell" if side == "long" else "buy",
            stopPrice=sl_price,
            amount=config['amount'],
            params=params
        )

        tp_order = self.exchange.create_order(
            symbol=self.symbol,
            type="TAKE_PROFIT_MARKET",
            side="sell" if side == "long" else "buy",
            stopPrice=tp_price,
            amount=config['amount'],
            params=params
        )

        print(f"[TP/SL] Đã đặt TP: {tp_price} và SL: {sl_price} (reduceOnly)")
