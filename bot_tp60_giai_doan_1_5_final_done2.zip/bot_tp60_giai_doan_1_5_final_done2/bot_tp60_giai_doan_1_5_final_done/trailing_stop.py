
def calculate_trailing_stop(entry_price, current_price, atr, step=0.3):
    """
    Dời SL theo trailing khi giá vượt TP1.
    Mặc định trailing = entry + (giá hiện tại - entry - 0.3 * ATR)
    """
    trailing_gap = step * atr
    new_sl = max(entry_price, current_price - trailing_gap)
    return round(new_sl, 2)
