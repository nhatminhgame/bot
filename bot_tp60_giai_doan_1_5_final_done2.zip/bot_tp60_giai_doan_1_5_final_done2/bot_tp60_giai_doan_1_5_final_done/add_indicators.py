import pandas as pd
import ta

# Đọc dữ liệu
df = pd.read_csv('ethusdt_15m_16features.csv')

# Tính chỉ báo kỹ thuật
df['volume'] = df['volume']  # giữ nguyên hoặc xử lý nếu volume bị thiếu

# Bollinger Bands
bb = ta.volatility.BollingerBands(close=df['close'])
df['volatility_bbm'] = bb.bollinger_mavg()
df['volatility_bbh'] = bb.bollinger_hband()
df['volatility_bbl'] = bb.bollinger_lband()

# EMA
df['trend_ema_fast'] = ta.trend.ema_indicator(df['close'], window=9)
df['trend_ema_slow'] = ta.trend.ema_indicator(df['close'], window=21)

# RSI
df['momentum_rsi'] = ta.momentum.rsi(df['close'], window=14)

# ATR
df['volatility_atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'], window=14)

# MACD
df['trend_macd'] = ta.trend.macd(df['close'])

# Williams %R
df['momentum_wr'] = ta.momentum.williams_r(df['high'], df['low'], df['close'])

# ADX
df['trend_adx'] = ta.trend.adx(df['high'], df['low'], df['close'])

# Ichimoku Base Line
df['trend_ichimoku_base'] = ta.trend.ichimoku_base_line(df['high'], df['low'])

# Awesome Oscillator
df['momentum_ao'] = ta.momentum.awesome_oscillator(df['high'], df['low'])

# KST Indicator
df['trend_kst'] = ta.trend.kst(df['close'])

# Xóa dòng NaN (do chỉ báo cần dữ liệu trước đó)
df = df.dropna().reset_index(drop=True)

# Lưu ra file mới
df.to_csv('ethusdt_15m_with_indicators.csv', index=False)
print("✅ Đã tính xong đầy đủ 14 chỉ báo kỹ thuật. File: ethusdt_15m_with_indicators.csv")
