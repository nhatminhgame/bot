import joblib

model = joblib.load("models/model_ethusdt_short.pkl")
print("✅ Các feature trong mô hình:")
for f in model.feature_name_:
    print("-", f)
