
pip install -r requirements.txt

nohup python3 bot_main.py > bot_log.txt 2>&1 &
