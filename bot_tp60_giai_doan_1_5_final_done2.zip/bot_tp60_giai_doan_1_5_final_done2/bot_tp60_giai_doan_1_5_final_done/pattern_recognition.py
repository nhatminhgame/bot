
def is_bullish_engulfing(df):
    if len(df) < 3:
        return False
    prev = df.iloc[-2]
    before = df.iloc[-3]
    return (
        before['close'] < before['open'] and
        prev['close'] > prev['open'] and
        prev['close'] > before['open'] and
        prev['open'] < before['close']
    )

def is_pinbar(df):
    if len(df) < 2:
        return False
    candle = df.iloc[-2]
    body = abs(candle['close'] - candle['open'])
    tail = candle['high'] - candle['low']
    return tail > 2 * body and candle['close'] > candle['open']

def is_triangle_breakout(df):
    if len(df) < 15:
        return False
    recent_high = df['high'].rolling(10).max().iloc[-2]
    recent_low = df['low'].rolling(10).min().iloc[-2]
    last_close = df['close'].iloc[-1]
    return last_close > recent_high or last_close < recent_low
