import joblib
import pandas as pd
from features import FEATURE_COLUMNS  # Feature list 33 cột

# Load mô hình AI risk / trend / breakout đã train
model_risk = joblib.load("models/model_risk_classifier.pkl")
model_trend = joblib.load("models/model_trend_predictor.pkl")
model_breakout = joblib.load("models/model_breakout_classifier.pkl")

def risk_ai(df):
    try:
        X = df.iloc[-1:][FEATURE_COLUMNS]
        prob = model_risk.predict_proba(X)[0][1]
        print(f"[RISK AI] Risk prob: {prob:.2%}")
        return prob > 0.55
    except Exception as e:
        print(f"[RISK AI] Lỗi: {e}")
        return False

def trend_ai(df):
    try:
        X = df.iloc[-1:][FEATURE_COLUMNS]
        pred = model_trend.predict(X)[0]
        print(f"[TREND AI] Trend prediction: {pred}")
        return pred == 1
    except Exception as e:
        print(f"[TREND AI] Lỗi: {e}")
        return False

def breakout_ai(df):
    try:
        breakout_features = FEATURE_COLUMNS[:28]
        X = df.iloc[-1:][breakout_features]
        prob = model_breakout.predict_proba(X)[0][1]
        print(f"[BREAKOUT AI] Breakout prob: {prob:.2%}")
        return prob > 0.55
    except Exception as e:
        print(f"[BREAKOUT AI] Lỗi: {e}")
        return False
