
# risk_manager.py

def get_trade_allocation(ai_score, total_balance, leverage, price):
    if ai_score >= 0.85:
        pct = 10
    elif ai_score >= 0.80:
        pct = 5
    elif ai_score >= 0.75:
        pct = 3
    else:
        return 0

    trade_value = (pct / 100) * total_balance * leverage
    qty = round(trade_value / price, 3)
    return qty
