#!/bin/bash
pkill -f run_bot.sh
pkill -f main.py
echo "✅ Bot đã được dừng."
