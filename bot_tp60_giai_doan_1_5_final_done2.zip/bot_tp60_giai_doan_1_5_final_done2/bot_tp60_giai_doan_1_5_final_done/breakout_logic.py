
def detect_consolidation_zone(df, window=8, threshold=0.02):
    recent_df = df[-window:]
    high = recent_df['high'].max()
    low = recent_df['low'].min()
    spread = (high - low) / low
    if spread < threshold:
        return {'top': high, 'bottom': low, 'mid': (high + low) / 2,
                'width': high - low, 'start_time': recent_df.index[0], 'end_time': recent_df.index[-1]}
    return None

def confirm_breakout(df, zone, volume_multiplier=1.5):
    last_candle = df.iloc[-1]
    avg_volume = df[-10:]['volume'].mean()
    if last_candle['close'] > zone['top'] and last_candle['volume'] > avg_volume * volume_multiplier:
        return 'bullish'
    elif last_candle['close'] < zone['bottom'] and last_candle['volume'] > avg_volume * volume_multiplier:
        return 'bearish'
    return None

def generate_breakout_trade(zone, breakout_type, last_close):
    entry = last_close
    width = zone['width']
    if breakout_type == 'bullish':
        return {'entry': round(entry, 2), 'tp': round(entry + width, 2), 'sl': round(zone['bottom'], 2), 'direction': 'bullish'}
    elif breakout_type == 'bearish':
        return {'entry': round(entry, 2), 'tp': round(entry - width, 2), 'sl': round(zone['top'], 2), 'direction': 'bearish'}
    return None

def validate_trade_with_ai_and_risk(X_input, model_classifier, risk_level):
    prob = model_classifier.predict_proba([X_input])[0][1]
    if prob >= 0.70 and risk_level in ['LOW', 'MEDIUM']:
        return True, round(prob * 100, 2)
    return False, round(prob * 100, 2)


# ✅ Bổ sung hàm tổng hợp cho entry_logic.py gọi
def is_breakout(df):
    zone = detect_consolidation_zone(df)
    if zone:
        result = confirm_breakout(df, zone)
        if result in ['bullish', 'bearish']:
            return True, result, zone
    return False, None, None
