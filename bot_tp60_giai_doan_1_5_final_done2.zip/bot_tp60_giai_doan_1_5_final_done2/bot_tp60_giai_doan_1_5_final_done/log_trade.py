import csv
from datetime import datetime
import os
from telegram_notify import send_discord_message  # Bo sung phan goi Discord

def log_trade(entry_price, sl, tp, exit_price, pnl, ai_tp, score, group, active_indicators):
    time_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    win_loss = "WIN" if pnl > 0 else "LOSS"
    indicators_str = ",".join(active_indicators) if active_indicators else "None"

    # Ghi vào file CSV
    file_exists = os.path.isfile("log_trade_detailed.csv")
    with open("log_trade_detailed.csv", mode="a", newline="") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow([
                "Time", "Entry", "TP", "SL", "Close", "PnL",
                "Win/Loss", "AI TP %", "Score", "Group", "Indicators"
            ])
        writer.writerow([
            time_now, entry_price, tp, sl, exit_price, pnl,
            win_loss, round(ai_tp * 100, 2), score, group, indicators_str
        ])

    # Goi Discord
    msg = (
        f" ĐÓNG LỆNH\n"
        f" Time: {time_now}\n"
        f"Entry: {entry_price} | TP: {tp} | SL: {sl}\n"
        f"Close: {exit_price} | PnL: {pnl} → {win_loss}\n"
        f"Group: {group} | Indicators: {indicators_str}\n"
        f"Score: {score} | AI TP: {round(ai_tp*100)}%"
    )
    send_discord_message(msg)
