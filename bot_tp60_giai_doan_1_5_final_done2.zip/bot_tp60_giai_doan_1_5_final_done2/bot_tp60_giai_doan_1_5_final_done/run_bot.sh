#!/bin/bash
cd /root/bot_tp60_giai_doan_1_5_final_done2/bot_tp60_giai_doan_1_5_final_done/

while true
do
    echo "?? �ang chay bot..."
    nohup python3 main.py > bot_log.txt 2>&1
    echo "? Bot bi loi hoac dung, se khoi dong lai sau 10 gi�y..."
    sleep 10
done
