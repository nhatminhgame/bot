
import requests
import json

def send_discord_alert(webhook_url, message):
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "content": message
    }
    try:
        response = requests.post(webhook_url, headers=headers, data=json.dumps(payload))
        if response.status_code != 204 and response.status_code != 200:
            print(f"❌ Discord error: {response.status_code} | {response.text}")
        else:
            print("✅ Discord alert sent.")
    except Exception as e:
        print(f"❌ Exception sending Discord alert: {str(e)}")
