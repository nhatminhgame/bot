import pandas as pd

# Load dữ liệu có sẵn các chỉ báo
df = pd.read_csv("ethusdt_15m_with_indicators.csv")

# Tham số huấn luyện
TP = 0.015  # 1.5% Take Profit
SL = 0.01   # 1% Stop Loss
forward = 20  # số nến tương lai để xét

target_long = []
target_short = []
target_trend = []

for i in range(len(df) - forward):
    entry = df['close'].iloc[i]
    highs = df['high'].iloc[i+1:i+1+forward]
    lows = df['low'].iloc[i+1:i+1+forward]
    future_close = df['close'].iloc[i+forward]

    # LONG: kiểm tra TP trước SL
    result_long = 0
    for h, l in zip(highs, lows):
        if h >= entry * (1 + TP):
            result_long = 1  # TP xảy ra trước
            break
        if l <= entry * (1 - SL):
            result_long = 0  # SL xảy ra trước
            break
    target_long.append(result_long)

    # SHORT: kiểm tra TP trước SL
    result_short = 0
    for h, l in zip(highs, lows):
        if l <= entry * (1 - TP):
            result_short = 1  # TP xảy ra trước
            break
        if h >= entry * (1 + SL):
            result_short = 0  # SL xảy ra trước
            break
    target_short.append(result_short)

    # TREND: dùng đóng cửa nến cuối so với entry
    if future_close > entry * 1.002:
        trend = 1
    elif future_close < entry * 0.998:
        trend = -1
    else:
        trend = 0
    target_trend.append(trend)

# Bù dòng còn thiếu ở cuối
pad = len(df) - len(target_long)
df['target_long'] = target_long + [0]*pad
df['target_short'] = target_short + [0]*pad
df['target_trend'] = target_trend + [0]*pad

# Lưu lại file
df.to_csv("ethusdt_15m_ready.csv", index=False)
print("✅ Đã chuẩn hóa và lưu lại dữ liệu huấn luyện: ethusdt_15m_ready.csv")
