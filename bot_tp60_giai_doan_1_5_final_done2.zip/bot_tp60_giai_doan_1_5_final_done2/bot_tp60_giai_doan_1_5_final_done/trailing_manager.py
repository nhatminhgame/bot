# trailing_manager.py – Kích hoạt trailing stop sau TP1

def activate_trailing(tp1_price, atr, direction="long"):
    # Trả về trailing SL sau TP1
    if direction == "long":
        new_sl = tp1_price - 0.3 * atr
    else:
        new_sl = tp1_price + 0.3 * atr
    return new_sl