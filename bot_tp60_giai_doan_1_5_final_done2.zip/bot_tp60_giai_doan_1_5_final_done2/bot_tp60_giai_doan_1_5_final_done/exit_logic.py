
from ai_predict import predict_prob
from entry_group_logic import check_entry_groups_verbose
from breakout_logic import is_breakout
from config import config
from telegram_notify import send_telegram

symbol = config["symbol"]

def check_entry_signal(df, symbol="ETH/USDT", signal_type="long"):
    try:
        ai_tp = predict_prob(df, symbol=symbol, signal_type=signal_type)
    except:
        ai_tp = 0.0

    score = 0
    if ai_tp >= 0.55:
        score += 4
    group_triggered, active_indicators = check_entry_groups_verbose(df)
    if group_triggered:
        score += 4
    if is_breakout(df):
        score += 2

    entry_price = df["close"].iloc[-1]
    atr = df["atr"].iloc[-1]

    if score >= 8:
        msg = (
            f"[ALERT] M? L?NH\n"
            f"Group: {group_triggered}\n"
            f"Indicators: {', '.join(active_indicators)}\n"
            f"Score: {score} | AI TP: {round(ai_tp * 100)}%"
        )
        send_telegram(msg)

    return {
        "entry_signal": score >= 8,
        "score": score,
        "ai_tp": ai_tp,
        "entry_price": entry_price,
        "sl": entry_price - 1.5 * atr,
        "tp": entry_price + 2.5 * atr,
        "group": group_triggered,
        "indicators": active_indicators,
        "note": f"TP={round(ai_tp*100)}%, score={score}"
    }
