
# === Nhóm G: Entry theo AI TP Classifier ===
def check_entry_group_g(df_recent, model_long, model_short, trend_model):
    features = extract_features(df_recent)
    ai_tp = model_long.predict_proba([features])[0][1]

    if ai_tp >= 0.60:
        print(f"✅ Nhóm G (AI TP) đủ điều kiện với TP={ai_tp:.2f}")
        return {
            "entry_signal": True,
            "confidence": ai_tp,
            "group": "G",
            "note": f"AI TP = {ai_tp:.2f}"
        }
    return {"entry_signal": False}

# === Nhóm H: Entry theo Group Scoring (nhiều chỉ báo kỹ thuật) ===
def check_entry_group_h(df_recent):
    total_score = 0
    explain = []

    # Ví dụ các điểm số đơn giản từ chỉ báo
    if df_recent["rsi"].iloc[-1] > 55:
        total_score += 0.4
        explain.append("RSI > 55")
    if df_recent["macd_hist"].iloc[-1] > 0:
        total_score += 0.3
        explain.append("MACD histogram dương")
    if df_recent["ema_fast"].iloc[-1] > df_recent["ema_slow"].iloc[-1]:
        total_score += 0.3
        explain.append("EMA crossover")

    if total_score >= 0.9:
        print(f"✅ Nhóm H (Group Score) đủ điều kiện: {total_score:.2f}")
        return {
            "entry_signal": True,
            "confidence": total_score,
            "group": "H",
            "note": " + ".join(explain)
        }
    return {"entry_signal": False}

# === Nhóm G mở rộng: AI TP + Group Score + Breakout Volume ===
def check_entry_group_g(df_recent, model_long, model_short, trend_model):
    total_score = 0
    explain = []

    # AI TP
    features = extract_features(df_recent)
    ai_tp = model_long.predict_proba([features])[0][1]
    if ai_tp >= 0.60:
        total_score += 0.6
        explain.append(f"AI TP={ai_tp:.2f}")

    # Group Score từ chỉ báo
    if df_recent["rsi"].iloc[-1] > 55:
        total_score += 0.15
        explain.append("RSI > 55")
    if df_recent["macd_hist"].iloc[-1] > 0:
        total_score += 0.15
        explain.append("MACD histogram dương")
    if df_recent["ema_fast"].iloc[-1] > df_recent["ema_slow"].iloc[-1]:
        total_score += 0.1
        explain.append("EMA crossover")

    # Breakout volume (dựa BB + volume spike)
    last_vol = df_recent["volume"].iloc[-1]
    avg_vol = df_recent["volume"].iloc[-50:].mean()
    bb_width = df_recent["bb_upper"].iloc[-1] - df_recent["bb_lower"].iloc[-1]
    bb_width_mean = df_recent["bb_upper"].iloc[-50:].mean() - df_recent["bb_lower"].iloc[-50:].mean()

    if last_vol > 1.5 * avg_vol and bb_width > 1.3 * bb_width_mean:
        total_score += 0.2
        explain.append("Breakout volume + BB mở rộng")

    if total_score >= 0.9:
        print(f"✅ Nhóm G (AI+Score+Breakout) đủ điều kiện: {total_score:.2f}")
        return {
            "entry_signal": True,
            "confidence": total_score,
            "group": "G",
            "note": " + ".join(explain)
        }
    return {"entry_signal": False}
