import pandas as pd
import joblib
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load dữ liệu đã chuẩn hóa
DATA_PATH = "ethusdt_15m_ready.csv"
df = pd.read_csv(DATA_PATH)

# --- Danh sách feature giống các model khác ---
features = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal', 'adx', 'atr',
    'ema_fast', 'ema_slow', 'volatility_bbh', 'momentum_wr',
    'trend_macd', 'trend_kst', 'momentum_ao',
    'trend_ichimoku_base', 'trend_adx'
]

# --- Tạo target_risk ---
target_risk = []
for _, row in df.iterrows():
    macd_trending = abs(row['macd'] - row['macd_signal']) > 0.5
    ema_trending = abs(row['ema_fast'] - row['ema_slow']) / row['close'] > 0.003
    adx_strong = row['adx'] > 20
    target_risk.append(int(macd_trending and ema_trending and adx_strong))
df['target_risk'] = target_risk

# --- Tạo target_breakout ---
target_breakout = []
for i in range(len(df)):
    vol_spike = df['volume'].iloc[i] > df['volume'].rolling(20).mean().iloc[i]
    bb_proximity = abs(df['close'].iloc[i] - df['volatility_bbh'].iloc[i]) / df['close'].iloc[i] < 0.01
    macd_cross = abs(df['macd'].iloc[i] - df['macd_signal'].iloc[i]) < 0.05
    target_breakout.append(int(vol_spike and bb_proximity and macd_cross))
df['target_breakout'] = target_breakout

# --- Huấn luyện mô hình Risk ---
X = df[features]
y_risk = df['target_risk']
model_risk = lgb.LGBMClassifier(n_estimators=200, learning_rate=0.03)
model_risk.fit(X, y_risk)
joblib.dump(model_risk, "models/model_risk_classifier.pkl")
print("✅ Saved model_risk_classifier.pkl")

# --- Huấn luyện mô hình Breakout ---
y_breakout = df['target_breakout']
model_breakout = lgb.LGBMClassifier(n_estimators=200, learning_rate=0.03)
model_breakout.fit(X, y_breakout)
joblib.dump(model_breakout, "models/model_breakout_classifier.pkl")
print("✅ Saved model_breakout_classifier.pkl")
