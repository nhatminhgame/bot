# -*- coding: utf-8 -*-
import pandas as pd
import ta
import lightgbm as lgb
import pickle
import os

# ====== 1. Đọc dữ liệu gốc ======
file_in = "ethusdt_15m.csv"
if not os.path.isfile(file_in):
    raise Exception(f"Không tìm thấy file {file_in} trong thư mục!")

df = pd.read_csv(file_in)
print(f"Đã đọc {len(df)} dòng dữ liệu từ {file_in}")

# ====== 2. Tính chỉ báo kỹ thuật ======
print("Đang tính các chỉ báo kỹ thuật...")
df['ema_fast'] = ta.trend.ema_indicator(df['close'], window=9)
df['ema_slow'] = ta.trend.ema_indicator(df['close'], window=21)
df['rsi'] = ta.momentum.rsi(df['close'], window=14)
df['atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'], window=14)
df['macd'] = ta.trend.macd(df['close'])

df = df.dropna().reset_index(drop=True)
print(f"Sau khi xóa NaN còn lại {len(df)} dòng.")

# ====== 3. Tạo cột target_long, target_short ======
print("Đang tạo cột target_long và target_short...")
TP = 0.01  # TP 1%
SL = 0.01  # SL 1%
forward = 5  # kiểm tra 5 nến tới

target_long, target_short = [], []
for i in range(len(df) - forward):
    entry = df['close'].iloc[i]
    highs = df['high'].iloc[i+1:i+1+forward]
    lows = df['low'].iloc[i+1:i+1+forward]
    # Target Long: TP trước SL?
    hit_tp_long = (highs >= entry * (1 + TP)).any()
    hit_sl_long = (lows <= entry * (1 - SL)).any()
    # Nếu đạt TP trước hoặc chỉ đạt TP, không bị SL, target=1
    target_long.append(int(hit_tp_long and not hit_sl_long))
    # Target Short: TP trước SL?
    hit_tp_short = (lows <= entry * (1 - TP)).any()
    hit_sl_short = (highs >= entry * (1 + SL)).any()
    target_short.append(int(hit_tp_short and not hit_sl_short))

while len(target_long) < len(df):
    target_long.append(0)
    target_short.append(0)

df['target_long'] = target_long
df['target_short'] = target_short

df.to_csv("ethusdt_15m_ready.csv", index=False)
print("Đã tạo file ethusdt_15m_ready.csv (có đủ chỉ báo & target)")

# ====== 4. Train AI cho Long ======
print("Đang train model AI Long...")
features = ['open', 'high', 'low', 'close', 'volume', 'atr', 'rsi', 'macd', 'ema_fast', 'ema_slow']
X = df[features]
y_long = df['target_long']
model_long = lgb.LGBMClassifier(n_estimators=200, learning_rate=0.05)
model_long.fit(X, y_long)
with open('model_bot_futures_ai.pkl', 'wb') as f:
    pickle.dump(model_long, f)
print("Đã lưu model Long vào model_bot_futures_ai.pkl")

# ====== 5. Train AI cho Short ======
print("Đang train model AI Short...")
y_short = df['target_short']
model_short = lgb.LGBMClassifier(n_estimators=200, learning_rate=0.05)
model_short.fit(X, y_short)
with open('model_bot_futures_ai_short.pkl', 'wb') as f:
    pickle.dump(model_short, f)
print("Đã lưu model Short vào model_bot_futures_ai_short.pkl")

print("✅ Xong toàn bộ! Có thể lấy 2 file model pkl dùng cho bot trade.")
