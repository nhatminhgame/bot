
from flask import Flask, render_template_string
import json
import os

app = Flask(__name__)

@app.route('/')
def home():
    if os.path.exists("bot_status.json"):
        with open("bot_status.json", "r") as f:
            status = json.load(f)
    else:
        status = {"status": "No active trade"}

    html = '''
    <h2>Bot Dashboard</h2>
    <ul>
    {% for key, value in status.items() %}
        <li><b>{{ key }}</b>: {{ value }}</li>
    {% endfor %}
    </ul>
    '''
    return render_template_string(html, status=status)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860)
