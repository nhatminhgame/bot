# train_entry_model.py
import pandas as pd
import numpy as np
import joblib
from lightgbm import LGBMRegressor
from ta.momentum import RSIIndicator
from ta.volatility import AverageTrueRange
from ta.trend import MACD, EMAIndicator

# === 1. Load dữ liệu nến ===
df = pd.read_csv("ethusdt_15m.csv")
df = df.dropna()

# === 2. Tính chỉ báo kỹ thuật ===
df['rsi'] = RSIIndicator(close=df['close']).rsi()
df['atr'] = AverageTrueRange(df['high'], df['low'], df['close']).average_true_range()
df['macd'] = MACD(df['close']).macd_diff()
df['ema_fast'] = EMAIndicator(df['close'], window=9).ema_indicator()
df['ema_slow'] = EMAIndicator(df['close'], window=21).ema_indicator()
df['ema_diff'] = df['ema_fast'] - df['ema_slow']

# === 3. Tính nhãn: entry_offset = (đáy 3 nến tới - close) / close ===
future_low = df['low'].shift(-1).rolling(window=3).min()
df['entry_offset'] = (future_low - df['close']) / df['close']

# === 4. Dọn dữ liệu ===
df = df.dropna()
X = df[['rsi', 'atr', 'macd', 'ema_diff']]
y = df['entry_offset']

# === 5. Huấn luyện mô hình ===
model = LGBMRegressor(n_estimators=200, random_state=42)
model.fit(X, y)

# === 6. Lưu model ===
joblib.dump(model, "model_entry_regressor.pkl")
print("✅ Đã lưu model_entry_regressor.pkl thành công.")
