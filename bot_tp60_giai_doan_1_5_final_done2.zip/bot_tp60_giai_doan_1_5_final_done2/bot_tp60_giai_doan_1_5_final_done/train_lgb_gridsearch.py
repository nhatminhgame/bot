
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import roc_auc_score
import joblib

# Load dữ liệu
df = pd.read_csv("ethusdt_15m.csv")  # đảm bảo file này tồn tại cùng thư mục hoặc điều chỉnh đường dẫn

# Tiền xử lý đơn giản
df = df.dropna()
X = df.drop(columns=["target"])
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model và GridSearch
model = lgb.LGBMClassifier()

param_grid = {
    "num_leaves": [15, 31, 63],
    "learning_rate": [0.01, 0.05, 0.1],
    "n_estimators": [100, 200]
}

grid = GridSearchCV(model, param_grid, scoring="roc_auc", cv=3, verbose=1)
grid.fit(X_train, y_train)

# Đánh giá
best_model = grid.best_estimator_
y_pred = best_model.predict_proba(X_test)[:, 1]
auc = roc_auc_score(y_test, y_pred)
print("Best AUC:", auc)

# Lưu mô hình
joblib.dump(best_model, "model_lgb_optimized.pkl")
print("Model saved as model_lgb_optimized.pkl")
