import requests
from config import config

# ✅ Gửi về Discord
def send_discord_message(msg):
    try:
        url = config.get("discord_webhook")
        if url:
            data = {"content": msg}
            response = requests.post(url, json=data, timeout=10)
            if response.status_code != 204:
                print(f"[?] Discord response: {response.status_code}, {response.text}")
        else:
            print("[?] Chưa có webhook Discord trong config.")
    except Exception as e:
        print(f"[❌] Lỗi gửi Discord: {e}")

# ✅ Gửi về Telegram (nếu muốn dùng lại sau này)
def send_telegram_message(message):
    try:
        token = config.get("telegram_token")
        chat_id = config.get("telegram_chat_id")
        if token and chat_id:
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            data = {"chat_id": chat_id, "text": message}
            response = requests.post(url, data=data, timeout=10)
            if response.status_code != 200:
                print(f"[?] Telegram response: {response.status_code}, {response.text}")
        else:
            print("[?] Thieu token/chat_id Telegram trong config.")
    except requests.exceptions.RequestException as e:
        print(f"[❌] Lỗi gửi Telegram: {e}")

# ✅ Giả lập in console nếu không bật gửi thật
def send_telegram_fake(msg):
    print(f"[ Gia lập Telegram] {msg}")
