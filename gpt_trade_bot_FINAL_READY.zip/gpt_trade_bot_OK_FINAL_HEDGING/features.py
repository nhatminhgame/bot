

# === extract_features nâng cấp ===
import pandas as pd
import ta

FEATURE_COLUMNS = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal', 'adx', 'atr',
    'ema_fast', 'ema_slow', 'volatility_bbh', 'momentum_wr', 'trend_macd',
    'trend_kst', 'momentum_ao', 'trend_ichimoku_base', 'trend_adx',
    'ema_distance', 'macd_histogram', 'atr_change', 'wick_ratio',
    'price_change_3', 'price_change_10', 'ema_fast_slope', 'bb_pos',
    'volume_change', 'rsi_slope', 'macd_cross', 'volatility_ratio',
    'rsi_1h', 'ema_1h', 'macd_1h', 'macd_signal_1h', 'volume_change_1h'
]

def extract_features(df_15m, df_1h):
    df = df_15m.copy()

    df['rsi'] = ta.momentum.RSIIndicator(df['close']).rsi()
    macd = ta.trend.MACD(df['close'])
    df['macd'], df['macd_signal'] = macd.macd(), macd.macd_signal()
    df['adx'] = ta.trend.ADXIndicator(df['high'], df['low'], df['close']).adx()
    df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close']).average_true_range()
    df['ema_fast'] = ta.trend.EMAIndicator(df['close'], window=9).ema_indicator()
    df['ema_slow'] = ta.trend.EMAIndicator(df['close'], window=21).ema_indicator()
    bb = ta.volatility.BollingerBands(df['close'])
    df['volatility_bbh'] = bb.bollinger_hband() - bb.bollinger_lband()
    df['momentum_wr'] = ta.momentum.WilliamsRIndicator(df['high'], df['low'], df['close']).williams_r()
    df['trend_macd'] = df['macd'] - df['macd_signal']
    df['trend_kst'] = ta.trend.KSTIndicator(df['close']).kst()
    df['momentum_ao'] = df['close'] - df['low'].rolling(5).mean()
    df['trend_ichimoku_base'] = (df['high'].rolling(9).max() + df['low'].rolling(26).min()) / 2
    df['trend_adx'] = df['adx']
    df['ema_distance'] = df['close'] - df['ema_fast']
    df['macd_histogram'] = df['macd'] - df['macd_signal']
    df['atr_change'] = df['atr'].pct_change()
    df['wick_ratio'] = (df['high'] - df['close']) / (df['high'] - df['low'] + 1e-9)
    df['price_change_3'] = df['close'].pct_change(3)
    df['price_change_10'] = df['close'].pct_change(10)
    df['ema_fast_slope'] = df['ema_fast'].diff()
    df['bb_pos'] = (df['close'] - bb.bollinger_lband()) / (bb.bollinger_hband() - bb.bollinger_lband() + 1e-9)
    df['volume_change'] = df['volume'].pct_change()
    df['rsi_slope'] = df['rsi'].diff()
    df['macd_cross'] = (df['macd'] > df['macd_signal']).astype(int)
    df['volatility_ratio'] = df['volatility_bbh'] / df['close']

    # Gộp thêm từ khung 1H
    for col in ['rsi', 'ema_fast', 'macd', 'macd_signal', 'volume']:
        df[f"{col}_1h"] = df_1h[col].reindex(df.index, method='ffill')

    return df