# -*- coding: utf-8 -*-
import json
import datetime
from utils.logger import log_info
from utils.discord import send_discord_alert

last_report_time = None

async def report_no_entry(gpt_reply, market, recent_candles):
    global last_report_time

    now = datetime.datetime.now()
    if last_report_time and (now - last_report_time).seconds < 900:
        return

    last_report_time = now

    message = "[ KHÔNG vào lệnh] GPT trả về action: none\n"

    if isinstance(gpt_reply, dict):
        action = gpt_reply.get("action", "none")
        confidence = gpt_reply.get("confidence", 0)
        message += f"• Action: {action}\n"
        message += f"• Confidence: {confidence}\n"
    else:
        message += f"GPT trả về không hợp lệ: {gpt_reply}"

    message += f"\nGiá hiện tại: {market.get('price')}"
    message += f"\nKhung RSI: {market.get('rsi_15m', '?')}, Trend: {market.get('trend', '?')}"

    await send_discord_alert(message)
    await log_info("Đã gửi lý do KHÔNG vào lệnh.")


# === report_no_entry_v2 (nâng cấp) ===
def report_no_entry_v2(decision, features, trend_1h, trend_4h, price, risk_level):
    msg = f"""📉 KHÔNG vào lệnh | GPT quyết định: ❌ {decision['action']}
• Độ tin cậy: {round(decision['confidence'] * 100)}%
• Lý do: {decision['reason']}
• RSI 15m: {features.get('rsi')} | Trend: 1H = {trend_1h}, 4H = {trend_4h}
• Risk level: {'🟢 LOW' if risk_level=='low' else '⚠️ HIGH' if risk_level=='high' else '🔥 VERY HIGH' if risk_level=='very_high' else '🟡 MEDIUM'}
• Giá hiện tại: {price}
"""
    send_discord_alert(msg)