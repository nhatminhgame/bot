import asyncio
import os
import json
from dotenv import load_dotenv

from utils.discord import send_discord_alert
from gpt.gpt_advisor import ask_gpt
from gpt.prompt_formatter import format_market_data_to_prompt
from trade.trade_executor import execute_gpt_decision
from trade.trade_state import load_trade_state
from trade.result_checker import check_tp_sl_hit
from risk.trailing_stop_manager import update_trailing_stop
from utils.logger import log_info
from utils.market_fetcher import fetch_market_data
from utils.candle_buffer import update_candle_buffer, get_recent_candles, initialize_candle_buffer
from entry_report import report_no_entry
from config import config  # L?y symbol, exchange

load_dotenv()

LAST_GPT_RESULT_PATH = "logs/last_gpt_result.json"


def load_last_gpt_result():
    os.makedirs(os.path.dirname(LAST_GPT_RESULT_PATH), exist_ok=True)
    if not os.path.exists(LAST_GPT_RESULT_PATH):
        return {}
    try:
        with open(LAST_GPT_RESULT_PATH, "r") as f:
            return json.load(f)
    except:
        return {}


def save_last_gpt_result(result):
    os.makedirs(os.path.dirname(LAST_GPT_RESULT_PATH), exist_ok=True)
    with open(LAST_GPT_RESULT_PATH, "w") as f:
        json.dump(result, f)


async def main_loop():
    await send_discord_alert("Bot GPT Trade da khoi dong va san sang hoat dong.")
    initialize_candle_buffer()

    symbol = config['symbol']
    exchange = config['exchange']

    while True:
        try:
            market = fetch_market_data()
            update_candle_buffer(market)

            state = load_trade_state()
            position = state.get("position")
            current_price = market["price"]

            check_tp_sl_hit(current_price, symbol, position)
            update_trailing_stop(current_price)

            recent_candles = get_recent_candles()
            if not recent_candles or len(recent_candles) < 5:
                await log_info("? recent_candles thieu du lieu, bo qua vong lap.")
                await asyncio.sleep(60)
                continue

            prompt = format_market_data_to_prompt(market, position, recent_candles)

            await log_info(f"[DEBUG] MARKET INPUT: {market}")
            await log_info(f"[DEBUG] LAST CANDLE: {recent_candles[-1]}")

            gpt_reply = await ask_gpt(prompt)

            await log_info(f"GPT tra loi: {gpt_reply}")
            save_last_gpt_result(gpt_reply)

            if gpt_reply.get("action") == "none":
                await report_no_entry(gpt_reply, market, recent_candles)
            else:
                await execute_gpt_decision(exchange, symbol, gpt_reply, position, market)

        except Exception as e:
            import traceback
            trace = traceback.format_exc()
            await log_info(f"[LOI] Chi tiet:\n{trace}")

        await asyncio.sleep(300)


if __name__ == "__main__":
    asyncio.run(main_loop())
