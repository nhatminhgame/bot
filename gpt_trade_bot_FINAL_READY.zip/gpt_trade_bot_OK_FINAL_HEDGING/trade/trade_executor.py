import json
import os
from utils.logger import log_info
from utils.discord import send_discord_alert
from trade.trade_state import set_in_trade

TRADE_STATE_FILE = "trade_state.json"

def save_trade_state(state):
    with open(TRADE_STATE_FILE, "w") as f:
        json.dump(state, f)

def load_trade_state():
    if not os.path.exists(TRADE_STATE_FILE):
        return None
    with open(TRADE_STATE_FILE, "r") as f:
        return json.load(f)

def close_position(exchange, symbol, side, size):
    try:
        opposite = "sell" if side == "long" else "buy"
        exchange.create_order(
            symbol=symbol,
            side=opposite,
            type="MARKET",
            amount=size,
            position_side=side.upper()
        )
        print(f"Da dong vi the {side} bang MARKET.")
        set_in_trade(False)
        return True
    except Exception as e:
        print(f"Loi khi dong vi the {side}: {e}")
        return False

def place_tp_sl_orders(exchange, symbol, side, entry_price, qty):
    tp_pct = 0.01
    sl_pct = 0.005
    tp_price = entry_price * (1 + tp_pct) if side == "long" else entry_price * (1 - tp_pct)
    sl_price = entry_price * (1 - sl_pct) if side == "long" else entry_price * (1 + sl_pct)

    try:
        exchange.create_order(
            symbol=symbol,
            side="sell" if side == "long" else "buy",
            type="TAKE_PROFIT_MARKET",
            amount=qty,
            params={
                "stopPrice": round(tp_price, 2),
                "closePosition": True,
                "positionSide": side.upper()
            }
        )
        exchange.create_order(
            symbol=symbol,
            side="sell" if side == "long" else "buy",
            type="STOP_MARKET",
            amount=qty,
            params={
                "stopPrice": round(sl_price, 2),
                "closePosition": True,
                "positionSide": side.upper()
            }
        )
        print(f"Da dat TP ({tp_price}) va SL ({sl_price}) cho {side}.")
    except Exception as e:
        print(f"Loi khi dat TP/SL: {e}")

async def execute_gpt_decision(exchange, symbol, decision, position, market):
    action = decision.get("action")
    confidence = decision.get("confidence", 0)
    print(f"GPT action: {action} | Confidence: {confidence:.2f}")

    if action == "none":
        print("GPT khong de xuat hanh dong.")
        return

    entry_price = float(market["price"])
    qty = 0.1  # tuy config

    # THOAT LENH
    if action in ["exit", "close_long", "close_short"] and position:
        side = position["side"]
        if action == "exit" or (action == "close_long" and side == "long") or (action == "close_short" and side == "short"):
            size = abs(float(position["positionAmt"]))
            if close_position(exchange, symbol, side, size):
                await send_discord_alert(f"Da dong vi the {side.upper()} theo GPT")
                await log_info(f"Thoat {side} tai {entry_price}")
        return

    # DAO CHIEU
    if action == "reverse" and position:
        side = position["side"]
        size = abs(float(position["positionAmt"]))
        new_side = "short" if side == "long" else "long"
        if close_position(exchange, symbol, side, size):
            direction = "buy" if new_side == "long" else "sell"
            exchange.create_order(symbol=symbol, side=direction, type="MARKET", amount=size, position_side=new_side.upper())
            place_tp_sl_orders(exchange, symbol, new_side, entry_price, size)
            set_in_trade(new_side, True)
            await send_discord_alert(f"Da dao chieu sang {new_side.upper()}")
        return

    # MO LENH LONG/SHORT
    if action in ["long", "short"]:
        if not position or position["side"] != action:
            direction = "buy" if action == "long" else "sell"
            exchange.create_order(symbol=symbol, side=direction, type="MARKET", amount=qty, position_side=action.upper())
            place_tp_sl_orders(exchange, symbol, action, entry_price, qty)
            set_in_trade(action, True)
            await send_discord_alert(f"Da mo lenh {action.upper()} tai {entry_price}")
