import json
import os

STATE_FILE = "logs/trade_state.json"

_state = {
    "long": {
        "entry_price": None,
        "tp": None,
        "sl": None,
        "active": False
    },
    "short": {
        "entry_price": None,
        "tp": None,
        "sl": None,
        "active": False
    }
}

def save_trade_state():
    with open(STATE_FILE, "w") as f:
        json.dump(_state, f)

def load_trade_state():
    global _state
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            _state.update(json.load(f))

def set_position(side: str, entry_price: float, tp: float, sl: float):
    _state[side] = {
        "entry_price": entry_price,
        "tp": tp,
        "sl": sl,
        "active": True
    }
    save_trade_state()

def clear_position(side: str):
    _state[side] = {
        "entry_price": None,
        "tp": None,
        "sl": None,
        "active": False
    }
    save_trade_state()

def get_position(side: str):
    return _state[side]

def has_position(side: str):
    return _state[side]["active"]


# === save_trade_state + load_trade_state nâng cấp ===
import json
import os

STATE_FILE = "open_trade.json"

def save_trade_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

def load_trade_state():
    if not os.path.exists(STATE_FILE):
        return {}
    with open(STATE_FILE, "r") as f:
        return json.load(f)

def set_in_trade(value: bool):
    state = load_trade_state()
    state["in_trade"] = value
    save_trade_state(state)

def is_in_trade():
    state = load_trade_state()
    return state.get("in_trade", False)

def set_in_trade(side: str, value: bool):
    state = load_trade_state()
    key = f"in_trade_{side.lower()}"
    state[key] = value
    save_trade_state(state)

def is_in_trade(side: str):
    state = load_trade_state()
    key = f"in_trade_{side.lower()}"
    return state.get(key, False)