import os
import json
from datetime import datetime
from dotenv import load_dotenv
from utils.logger import log_info
from openai import OpenAI

# ✅ Load biến môi trường .env TRƯỚC KHI dùng
load_dotenv()

# ✅ Lấy config từ biến môi trường
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GPT_DAILY_LIMIT = int(os.getenv("GPT_DAILY_LIMIT", 100))
GPT_MODEL = os.getenv("GPT_MODEL", "gpt-4o")

if not OPENAI_API_KEY:
    raise ValueError("❌ OPENAI_API_KEY chưa được thiết lập trong .env hoặc biến môi trường!")

# ✅ Tạo client GPT sau khi chắc chắn có API key
client = OpenAI(api_key=OPENAI_API_KEY)

USAGE_FILE = "logs/gpt_usage.json"
DECISION_LOG_FILE = "logs/gpt_decision_log.json"
GPT_LOG_FILE = "logs/gpt_training_data.jsonl"
os.makedirs("logs", exist_ok=True)


def _load_usage():
    try:
        with open(USAGE_FILE, "r") as f:
            return json.load(f)
    except:
        return {"count": 0, "date": ""}


def _save_usage(data):
    with open(USAGE_FILE, "w") as f:
        json.dump(data, f)


def _log_decision(prompt, gpt_reply):
    try:
        parsed_reply = json.loads(gpt_reply) if isinstance(gpt_reply, str) else gpt_reply
    except:
        parsed_reply = {"error": "invalid_format", "raw": gpt_reply}

    log = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prompt": prompt,
        "gpt_reply": parsed_reply
    }

    try:
        with open(DECISION_LOG_FILE, "r") as f:
            data = json.load(f)
            if not isinstance(data, list):
                data = []
    except:
        data = []

    data.append(log)
    with open(DECISION_LOG_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def log_gpt_training_data(prompt, response):
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "prompt": prompt,
        "response": response
    }
    with open(GPT_LOG_FILE, "a") as f:
        f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")


# ✅ HÀM CHÍNH DÙNG ĐỂ IMPORT
async def ask_gpt(prompt: str):
    usage = _load_usage()
    today = datetime.now().strftime("%Y-%m-%d")
    if usage["date"] != today:
        usage = {"count": 0, "date": today}
    if usage["count"] >= GPT_DAILY_LIMIT:
        log_info(" Đã vượt giới hạn GPT daily")
        return {"action": "none", "confidence": 0.0, "reason": "limit_exceeded"}

    try:
        response = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[
                {"role": "system", "content": (
                    "Bạn là một chuyên gia giao dịch crypto. "
                    "Hãy phân tích thị trường và trả về kết quả bằng JSON với các trường sau:\n"
                    "- action: \"long\", \"short\", \"close\", hoặc \"none\"\n"
                    "- confidence: độ tin cậy từ 0 đến 1\n"
                    "- reason: giải thích ngắn gọn vì sao chọn action (nếu là none thì phải ghi rõ lý do)\n"
                    "Ví dụ: {\"action\": \"none\", \"confidence\": 0.42, \"reason\": \"Giá đang sideway\"}"
                )},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )

        usage["count"] += 1
        _save_usage(usage)

        reply_text = response.choices[0].message.content.strip()

        # Xử lý nếu GPT trả về trong khối ```json ... ```
        if reply_text.startswith("```"):
            reply_text = reply_text.strip("`").strip()
            if reply_text.lower().startswith("json"):
                reply_text = reply_text[4:].strip()

        await log_info(f"GPT RAW: {reply_text}")
        _log_decision(prompt, reply_text)

        try:
            reply_json = json.loads(reply_text)
            assert isinstance(reply_json, dict) and "action" in reply_json
        except Exception as e:
            log_info(f" GPT trả về sai định dạng: {e}")
            reply_json = {"action": "none", "confidence": 0.0, "reason": "format_error"}

        # Ghi log training
        log_gpt_training_data(prompt, {
            "action": reply_json.get("action"),
            "confidence": reply_json.get("confidence"),
            "reason": reply_json.get("reason")
        })

        return reply_json

    except Exception as e:
        log_info(f"❌ Lỗi GPT: {e}")
        return {"action": "none", "confidence": 0.0, "reason": "api_error"}
