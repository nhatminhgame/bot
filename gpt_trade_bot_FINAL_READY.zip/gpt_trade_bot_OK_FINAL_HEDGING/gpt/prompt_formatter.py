# -*- coding: utf-8 -*-
from utils.indicator_summary import summarize_indicators

def format_market_data_to_prompt(market: dict, position: dict, recent_candles: list):
    indicators_15m = summarize_indicators(market, timeframe="15m")
    indicators_1h = summarize_indicators(market, timeframe="1h")
    indicators_4h = summarize_indicators(market, timeframe="4h")

    candle_data = "\n".join([
        f"{c.get('time', '???')}: close={c.get('close', '?')}, rsi={c.get('rsi', '?')}, macd={c.get('macd', '?')}, macd_signal={c.get('macd_signal', '?')}, ema_fast={c.get('ema_fast', '?')}, ema_slow={c.get('ema_slow', '?')}, vol={c.get('volume', '?')}, trend={c.get('trend', '?')}"
        for c in recent_candles
    ])

    position_text = "Không có vị thế hiện tại."
    if position:
        position_text = f"Đang giữ vị thế {position['side']} tại giá {position['entry_price']}"

    return f"""
 DỮ LIỆU KỸ THUẬT:
• 15m: {indicators_15m}
• 1h: {indicators_1h}
• 4h: {indicators_4h}

 10 NẾN GẦN NHẤT:
{candle_data}

 TRẠNG THÁI LỆNH:
{position_text}

HÃY PHÂN TÍCH:
1. Dựa trên chuỗi RSI, MACD, EMA, volume, đánh giá xu hướng thị trường hiện tại.
2. Có tín hiệu rõ ràng để vào lệnh không? Long hay Short?
3. Tự đánh giá mức độ tự tin (confidence) từ 0 đến 1.
4. Nếu không nên vào lệnh, hãy nêu rõ lý do (ví dụ: thị trường sideway, tín hiệu xung đột, dữ liệu chưa đủ).
5. Nếu nên vào lệnh, nêu rõ lý do và đề xuất hành động phù hợp.

TRẢ VỀ JSON DUY NHẤT theo định dạng:
{{
  "action": "long" | "short" | "none" | "close",
  "confidence": 0.xx,
  "reason": "..."  ← giải thích rõ vì sao chọn action (bắt buộc nếu action là 'none')
}}
"""

# === format_prompt_v2 (nâng cấp) ===
def format_market_data_to_prompt(candles_15m: list, current_features: dict, trend_1h: str, trend_4h: str, risk_level: str, position: dict = None) -> str:
    """
    candles_15m: Danh sách 10–20 cây nến gần nhất (list of dicts)
    current_features: dict chứa các chỉ báo tại thời điểm hiện tại (đủ 33 chỉ báo)
    trend_1h, trend_4h: xu hướng từ hệ thống AI phân tích khung lớn
    position: dict chứa trạng thái lệnh hiện tại (nếu có), ví dụ:
      {
        "side": "long",
        "entry_price": 642.5,
        "size": 100,
        "unrealized_pnl": 1.8
      }
    """
    candle_summary = ""
    for c in candles_15m[-10:]:
        candle_summary += f"• [{c['timestamp']}] O:{c['open']:.2f} H:{c['high']:.2f} L:{c['low']:.2f} C:{c['close']:.2f} V:{c['volume']:.1f} RSI:{c.get('rsi', '?')}" + "\n"

    indicators = f"""
📊 **Chỉ báo kỹ thuật tại nến hiện tại:**
• Giá: {current_features.get('close')}
• RSI: {current_features.get('rsi')}, MACD: {current_features.get('macd')} | MACD Signal: {current_features.get('macd_signal')}
• EMA Fast: {current_features.get('ema_fast')}, EMA Slow: {current_features.get('ema_slow')}
• EMA Chênh lệch: {current_features.get('ema_fast') - current_features.get('ema_slow'):.4f}, EMA Slope: {current_features.get('ema_fast_slope')}
• MACD: {current_features.get('macd')}, MACD Signal: {current_features.get('macd_signal')}, MACD Histogram: {current_features.get('macd') - current_features.get('macd_signal'):.4f}
• ADX: {current_features.get('adx')}, ATR: {current_features.get('atr')}
• Volume: {current_features.get('volume')}, BB Pos: {current_features.get('bb_pos')}
• Trend 1H: {trend_1h}, Trend 4H: {trend_4h}
• Mức độ rủi ro thị trường: {risk_level.upper()}
"""

    if position:
        pos_text = f"""
📌 **Đang giữ lệnh:**
• Loại: {position['side'].upper()}
• Giá vào: {position['entry_price']}
• Khối lượng: {position['size']}
• Lãi/lỗ tạm tính: {position['unrealized_pnl']} USDT
"""
    else:
        pos_text = "\n📌 **Hiện không có vị thế đang mở.**"

    guide = """
🤖 Hãy phân tích toàn cảnh thị trường như một chuyên gia:
- Dựa trên lịch sử nến, chỉ báo kỹ thuật, trend đa khung.
- Nếu có vị thế đang mở, đánh giá nên giữ, thoát, hay đảo chiều.
- Nếu không có lệnh, đánh giá có nên vào lệnh LONG, SHORT hoặc đứng ngoài.

🎯 Trả lời theo cú pháp JSON chuẩn:
{
  "action": "long" | "short" | "none" | "close",
  "confidence": 0.0–1.0,
  "reason": "Giải thích ngắn gọn",
  "note": "Nhận định chi tiết nếu cần"
}
"""

    prompt = f"""🕒 **Lịch sử 10 nến 15m gần nhất:**\n{candle_summary}\n{indicators}\n{pos_text}\n{guide}"""
    return prompt