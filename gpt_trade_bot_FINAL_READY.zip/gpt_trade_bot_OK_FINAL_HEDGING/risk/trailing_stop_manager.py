from trade.trade_state import get_position, set_position
from utils.logger import log_info

TRAILING_PERCENT = 0.005  # 0.5%

def update_trailing_stop(current_price: float):
    for side in ["long", "short"]:
        pos = get_position(side)
        if not pos["active"]:
            continue

        entry = pos["entry_price"]
        tp = pos["tp"]
        sl = pos["sl"]

        if side == "long":
            new_sl = current_price * (1 - TRAILING_PERCENT)
            if new_sl > sl and current_price > entry:
                set_position("long", entry, tp, new_sl)
                log_info(f"🔁 Dời SL LONG lên {round(new_sl, 3)}")

        elif side == "short":
            new_sl = current_price * (1 + TRAILING_PERCENT)
            if new_sl < sl and current_price < entry:
                set_position("short", entry, tp, new_sl)
                log_info(f"🔁 Dời SL SHORT xuống {round(new_sl, 3)}")


# === update_trailing_stop (nâng cấp) ===
def update_trailing_stop(exchange, symbol, position, trailing_distance_pct=0.01):
    if not position:
        return

    side = position['side']
    entry_price = float(position['entry_price'])
    mark_price = float(position['mark_price'])
    stop_price = float(position.get('stop_loss', 0))
    position_amt = float(position['positionAmt'])

    # Nếu đang lỗ thì không trailing
    if (side == "long" and mark_price <= entry_price) or (side == "short" and mark_price >= entry_price):
        return

    # Tính trailing stop mới
    if side == "long":
        new_sl = mark_price * (1 - trailing_distance_pct)
        if new_sl > stop_price:
            exchange.set_stop_loss(symbol, side, new_sl, abs(position_amt))
    else:
        new_sl = mark_price * (1 + trailing_distance_pct)
        if new_sl < stop_price or stop_price == 0:
            exchange.set_stop_loss(symbol, side, new_sl, abs(position_amt))