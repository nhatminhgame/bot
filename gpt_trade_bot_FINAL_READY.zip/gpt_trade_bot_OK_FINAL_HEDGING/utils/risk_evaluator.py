

# === evaluate_risk_level (nâng cấp) ===
def evaluate_risk_level(row):
    rsi = row.get("rsi", 50)
    atr = row.get("atr", 0)
    volume = row.get("volume", 0)
    bb_width = row.get("volatility_bbh", 0)

    if volume > 3000 or atr > 20:
        return "very_high"
    elif rsi > 75 or rsi < 25:
        return "high"
    elif bb_width < 0.5 and atr < 2:
        return "low"
    else:
        return "medium"