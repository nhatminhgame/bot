import os
import aiohttp
from dotenv import load_dotenv

load_dotenv()
DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL", "")

async def send_discord_alert(message: str):
    if not DISCORD_WEBHOOK_URL:
        print(" DISCORD_WEBHOOK_URL chưa được cấu hình.")
        return

    try:
        async with aiohttp.ClientSession() as session:
            payload = {"content": message}
            async with session.post(DISCORD_WEBHOOK_URL, json=payload) as response:
                if response.status != 204 and response.status != 200:
                    print(f"❌ Gửi Discord thất bại: {response.status} - {await response.text()}")
    except Exception as e:
        print(f"❌ Lỗi khi gửi Discord: {e}")
