import requests
import time
from ai_predict import predict_prob
from entry_group_logic import check_entry_groups_verbose
from smart_risk import risk_ai, trend_ai, breakout_ai  # ✅ các hàm AI mới
from config import config
from features import extract_features  # ✅ THÊM DÒNG NÀY

last_report_time = 0

def send_discord_message(msg):
    try:
        url = config["discord_webhook"]
        data = {"content": msg}
        response = requests.post(url, json=data, timeout=10)
        if response.status_code != 204:
            print(f"[❌] Discord lỗi: {response.status_code} - {response.text}")
        else:
            print("[✅] Đã gửi Discord:", msg)
    except Exception as e:
        print(f"[❌] Lỗi khi gửi Discord: {e}")

symbol = config["symbol"]

def check_entry_signal(df, symbol="ETH/USDT"):
    global last_report_time
    now = time.time()

    try:
        # ✅ Gọi thử extract_features trực tiếp
        from features import extract_features  # nếu extract nằm trong ai_predict.py
        test_features = extract_features(df)

        print(" [DEBUG] Feature bot đang dùng:")
        if isinstance(test_features, dict):
            print("✅ Dict keys:", list(test_features.keys()))
        elif isinstance(test_features, (list, tuple)):
            print("✅ List:", test_features)
        elif hasattr(test_features, 'shape'):
            print("✅ Array shape:", test_features.shape)
        else:
            print(" Unknown type:", type(test_features))

        # Gọi predict_prob bình thường
        ai_tp_long = predict_prob(df, symbol=symbol, signal_type="long")
        ai_tp_short = predict_prob(df, symbol=symbol, signal_type="short")
    except Exception as e:
        print(f"❌ Lỗi khi gọi predict_prob hoặc extract_features: {e}")
        ai_tp_long = 0.0
        ai_tp_short = 0.0

    # Hướng AI chọn
    if ai_tp_long > ai_tp_short:
        ai_direction = "LONG"
    elif ai_tp_short > ai_tp_long:
        ai_direction = "SHORT"
    else:
        ai_direction = "-"

    # Score logic
    score = 0
    if ai_direction == "LONG" and ai_tp_long >= 0.55:
        score += 2
    elif ai_direction == "SHORT" and ai_tp_short >= 0.55:
        score += 2

    # Group logic
    raw_groups = check_entry_groups_verbose(df)
    agree_groups = (
        raw_groups if isinstance(raw_groups, dict)
        else raw_groups[0] if isinstance(raw_groups, tuple) and isinstance(raw_groups[0], dict)
        else {}
    )
    if len(agree_groups) >= 2:
        score += 2

    # AI Risk, Trend, Breakout
    risk = risk_ai(df)
    trend = trend_ai(df)
    breakout = breakout_ai(df)

    if risk:
        score += 2
    if trend:
        score += 2
    if breakout:
        score += 2

    entry_price = df["close"].iloc[-1]
    atr = df["atr"].iloc[-1] if "atr" in df.columns else 0

    group_str = "\n".join([f"   - {g}: {', '.join(v)}" for g, v in agree_groups.items()]) if agree_groups else ""

    if score >= 8:
        msg = (
            f"[ALERT] MỞ LỆNH\n"
            f"Group đạt: {len(agree_groups)} nhóm đồng thuận\n"
            f"{group_str}\n"
            f"Risk: ✅ {risk} | Trend: ✅ {trend} | Breakout: ✅ {breakout}\n"
            f"Score: {score} | Hướng AI: {ai_direction}\n"
            f"AI TP Long: {round(ai_tp_long * 100, 2)}% | Short: {round(ai_tp_short * 100, 2)}%"
        )
        send_discord_message(msg)
        last_report_time = now
    else:
        if now - last_report_time >= 900:
            msg = (
                f"❌ Chưa vào lệnh:\n"
                f"• AI TP Long: {round(ai_tp_long * 100, 2)}%\n"
                f"• AI TP Short: {round(ai_tp_short * 100, 2)}%\n"
                f"• Hướng AI chọn: {ai_direction}\n"
                f"• Group đạt: {len(agree_groups)} nhóm\n"
                f"• Risk: {risk} | Trend: {trend} | Breakout: {breakout}\n"
                f"→ Bot KHÔNG vào lệnh do chưa đủ điều kiện (score={score})"
            )
            send_discord_message(msg)
            last_report_time = now

    return {
        "entry_signal": score >= 8,
        "score": score,
        "ai_tp_long": ai_tp_long,
        "ai_tp_short": ai_tp_short,
        "entry_price": entry_price,
        "sl": entry_price - 1.5 * atr,
        "tp": entry_price + 2.5 * atr,
        "agree_groups": agree_groups,
        "group": f"{len(agree_groups)} nhóm",
        "note": f"TP Long={round(ai_tp_long*100)}%, Short={round(ai_tp_short*100)}%, score={score}, risk={risk}, trend={trend}, breakout={breakout}"
    }
