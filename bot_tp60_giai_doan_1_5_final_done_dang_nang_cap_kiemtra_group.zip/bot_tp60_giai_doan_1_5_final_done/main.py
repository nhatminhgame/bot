from config import config
symbol = config['symbol']
timeframe = config['interval']
from indicators import get_all_indicators
from features import extract_features
from ai_predict import predict_prob
from entry_logic import check_entry_signal
from telegram_notify import send_telegram_message
from telegram_notify import send_discord_message
from order_manager import OrderManager
from trailing_manager import activate_trailing
from log_trade import log_trade
import ccxt
import time

# ✅ Khai báo biến báo cáo toàn cục
last_report_time = 0

exchange = ccxt.binance({
    'enableRateLimit': True
})

def fetch_ohlcv():
    candles_15m = exchange.fetch_ohlcv(symbol, timeframe, limit=100)
    candles_1h = exchange.fetch_ohlcv(symbol, "1h", limit=100)
    
    import pandas as pd
    df_15m = pd.DataFrame(candles_15m, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df_1h = pd.DataFrame(candles_1h, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df = get_all_indicators(df_15m, df_1h)
    return df

# ✅ Gửi báo khi bot khởi động
send_discord_message("✅ Bot đã khởi động lại thành công\nCặp: ETH/USDT | Khung: 15m | Vào lệnh: AI + Group")

# ✅ Hàm báo cáo nếu chưa có lệnh sau 15 phút
def report_if_no_trade(signal_result):
    return
    global last_report_time
    now = time.time()
    if now - last_report_time >= 900:
        try:
            message = "❌ Chưa vào lệnh:\n"
            ai_tp_long = round(signal_result.get("ai_tp_long", 0) * 100, 2)
            ai_tp_short = round(signal_result.get("ai_tp_short", 0) * 100, 2)
            message += f"• AI TP: {ai_tp_percent:.2f}%\n"
            message += f"• Group đạt: {signal_result.get('group', '-')}\n"
            #message += f"• Breakout: {signal_result.get('breakout', '-')}\n"
            #message += f"• Trend: {signal_result.get('trend', '-')}\n"
            #message += f"• Risk: {signal_result.get('risk', '-')}\n"
            message += f"→ Bot KHÔNG vào lệnh do chưa đủ điều kiện"
            send_discord_message(message)
            last_report_time = now
        except Exception as e:
            print(f"[Lỗi báo cáo] {e}")

# ✅ Main loop
def main_loop():
    open_trade = None

    while True:
        try:
            df = fetch_ohlcv()
            signal = check_entry_signal(df, symbol="ETH/USDT")

            # Gửi báo nếu chưa có tín hiệu vào lệnh
            if open_trade is None and (not signal or not signal["entry_signal"]):
                report_if_no_trade(signal)

            # Nếu có tín hiệu hợp lệ
            if open_trade is None and signal and signal["entry_signal"]:
                manager = OrderManager(config)
                manager.place_order_limit_dca(
                    side="long",
                    size=0.05,
                    base_price=signal["entry_price"]
                )
                send_telegram_message(f"[Bot] Đã vào lệnh mới tại {signal['entry_price']} – nhóm kích hoạt: {signal['note']}")
                send_discord_message(f"[Bot] Đã vào lệnh mới tại {signal['entry_price']} – nhóm kích hoạt: {signal['note']}")
                open_trade = {
                    "entry": signal["entry_price"],
                    "sl": signal["sl"],
                    "tp": signal["tp"],
                    "atr": df["atr"].iloc[-1],
                    "ai_tp": signal["ai_tp"],
                    "score": signal["score"],
                    "group": signal["note"]
                }

            elif open_trade:
                price = df["close"].iloc[-1]
                entry = open_trade["entry"]
                tp = open_trade["tp"]
                sl = open_trade["sl"]
                atr = open_trade["atr"]

                if price >= tp:
                    new_sl = activate_trailing(tp, atr, direction="long")
                    send_telegram_message(f"[Bot] Đạt TP1, kích hoạt trailing SL tại {new_sl}")
                    send_discord_message(f"[Bot] Đạt TP1, kích hoạt trailing SL tại {new_sl}")
                    open_trade["sl"] = new_sl
                    open_trade["tp"] = price + atr

                elif price <= open_trade["sl"]:
                    pnl = price - entry
                    log_trade(entry, sl, tp, price, pnl,
                              open_trade["ai_tp"], open_trade["score"], open_trade["group"])
                    send_telegram_message(f"[Bot] Đóng lệnh tại {price} – PnL: {round(pnl, 2)}")
                    send_discord_message(f"[Bot] Đóng lệnh tại {price} – PnL: {round(pnl, 2)}")
                    open_trade = None

        except Exception as e:
            print(f"[Bot] Loi trong vòng lặp chính: {e}")

        time.sleep(60)

if __name__ == "__main__":
    main_loop()
