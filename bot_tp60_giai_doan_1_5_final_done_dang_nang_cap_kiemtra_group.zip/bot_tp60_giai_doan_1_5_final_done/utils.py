import ccxt
import pandas as pd
from config import config

def get_ohlcv_binance(symbol, timeframe, limit):
    exchange = ccxt.binance({
        'apiKey': config["apiKey"],
        'secret': config["secret"],
        'enableRateLimit': True,
        'options': {'defaultType': 'future'}
    })
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
    df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

def log_trade(msg):
    import os
    os.makedirs('logs', exist_ok=True)
    with open('logs/trade_log.txt', 'a') as f:
        f.write(f"{msg}\n")

def get_trade_size(df, config):
    # Thực tế nên lấy balance qua API
    balance = 1000
    trade_size = (balance * config['capital_percent']) * config['leverage']
    return round(trade_size, 4)
