import pandas as pd
import joblib
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

# --- BƯỚC 1: Đọc dữ liệu đã chuẩn hóa ---
df = pd.read_csv("ethusdt_15m_ready.csv")

features = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal', 'adx', 'atr',
    'ema_fast', 'ema_slow', 'volatility_bbh', 'momentum_wr',
    'trend_macd', 'trend_kst', 'momentum_ao',
    'trend_ichimoku_base', 'trend_adx'
]

# Kiểm tra đủ cột
assert all(col in df.columns for col in features), "❌ Thiếu feature!"

# --- BƯỚC 2: Tạo X và y ---
X = df[features]
y_long = df['target_long']
y_short = df['target_short']
y_trend = df['target_trend']

# --- BƯỚC 3: Train từng model ---

# Model 1: model_entry_regressor.pkl (dự đoán xác suất thắng nếu entry)
model_reg = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.03)
model_reg.fit(X, y_long)
joblib.dump(model_reg, "models/model_entry_regressor.pkl")
print("✅ Saved model_entry_regressor.pkl")

# Model 2: model_ethusdt_long.pkl
X_train, X_test, y_train, y_test = train_test_split(X, y_long, test_size=0.2, shuffle=False)
model_long = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.03)
model_long.fit(X_train, y_train)
auc = roc_auc_score(y_test, model_long.predict_proba(X_test)[:, 1])
joblib.dump(model_long, "models/model_ethusdt_long.pkl")
print(f"✅ Saved model_ethusdt_long.pkl (AUC = {auc:.4f})")

# Model 3: model_ethusdt_short.pkl
model_short = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.03)
model_short.fit(X, y_short)
joblib.dump(model_short, "models/model_ethusdt_short.pkl")
print("✅ Saved model_ethusdt_short.pkl")

# Model 4: model_trend_predictor.pkl (3 lớp: tăng - đứng - giảm)
model_trend = lgb.LGBMClassifier(
    n_estimators=300,
    learning_rate=0.03,
    objective='multiclass',
    num_class=3
)
model_trend.fit(X, y_trend)
joblib.dump(model_trend, "models/model_trend_predictor.pkl")
print("✅ Saved model_trend_predictor.pkl")
