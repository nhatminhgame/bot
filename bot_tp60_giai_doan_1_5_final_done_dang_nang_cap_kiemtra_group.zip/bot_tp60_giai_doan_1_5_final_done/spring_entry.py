
def detect_spring_entry(df):
    """
    Xác định tín hiệu Wyckoff Spring Entry:
    - Có breakdown xuống dưới hỗ trợ gần nhất
    - Volume tăng mạnh
    - Nến đảo chiều mạnh (pinbar hoặc engulfing)
    """
    if len(df) < 5:
        return False

    last = df.iloc[-1]
    prev = df.iloc[-2]
    support = df['low'].rolling(20).min().iloc[-2]

    # Điều kiện 1: Close < hỗ trợ, sau đó quay lại vùng trên hỗ trợ
    spring_fake_break = prev['close'] < support and last['close'] > support

    # Điều kiện 2: Volume tăng mạnh
    vol_ma = df['volume'].rolling(20).mean().iloc[-2]
    vol_spike = prev['volume'] > 1.5 * vol_ma

    # Điều kiện 3: Nến đảo chiều pinbar hoặc engulfing
    pinbar = (prev['low'] < df['low'].iloc[-3] and
              abs(prev['close'] - prev['open']) < 0.3 * (prev['high'] - prev['low']))

    engulfing = (prev['close'] > prev['open'] and
                 prev['close'] > df['open'].iloc[-3] and
                 prev['open'] < df['close'].iloc[-3])

    reversal_candle = pinbar or engulfing

    return spring_fake_break and vol_spike and reversal_candle
