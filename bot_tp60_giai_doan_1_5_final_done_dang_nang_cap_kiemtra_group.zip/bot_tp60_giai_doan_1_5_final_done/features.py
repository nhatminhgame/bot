FEATURE_COLUMNS = [
    "close", "volume", "rsi", "macd", "macd_signal", "adx", "atr",
    "ema_fast", "ema_slow", "volatility_bbh", "momentum_wr", "trend_macd",
    "trend_kst", "momentum_ao", "trend_ichimoku_base", "trend_adx",
    "ema_distance", "macd_histogram", "atr_change", "wick_ratio",
    "price_change_3", "price_change_10", "ema_fast_slope", "bb_pos",
    "volume_change", "rsi_slope", "macd_cross", "volatility_ratio",
    "rsi_1h", "ema_1h", "macd_1h", "macd_signal_1h", "volume_change_1h"
]

def extract_features(df):
    latest = df.iloc[-1]
    return [
        latest["close"],
        latest["volume"],
        latest["rsi"],
        latest["macd"],
        latest["macd_signal"],
        latest["adx"],
        latest["atr"],
        latest["ema_fast"],
        latest["ema_slow"],
        latest["volatility_bbh"],
        latest["momentum_wr"],
        latest["trend_macd"],
        latest["trend_kst"],
        latest["momentum_ao"],
        latest["trend_ichimoku_base"],
        latest["trend_adx"],
        latest["ema_distance"],
        latest["macd_histogram"],
        latest["atr_change"],
        latest["wick_ratio"],
        latest["price_change_3"],
        latest["price_change_10"],
        latest["ema_fast_slope"],
        latest["bb_pos"],
        latest["volume_change"],
        latest["rsi_slope"],
        latest["macd_cross"],
        latest["volatility_ratio"],
        latest["rsi_1h"],
        latest["ema_1h"],
        latest["macd_1h"],
        latest["macd_signal_1h"],
        latest["volume_change_1h"]
    ]
