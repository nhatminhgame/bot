import pandas as pd
import joblib

df = pd.read_csv("ethusdt_15m_with_indicators.csv")

features = [
    'close', 'volume', 'rsi', 'macd', 'macd_signal',
    'adx', 'atr', 'ema_fast', 'ema_slow', 'volatility_bbh',
    'momentum_wr', 'trend_macd', 'trend_kst',
    'momentum_ao', 'trend_ichimoku_base', 'trend_adx'
]

x = df[features].dropna().iloc[-1:]
model = joblib.load("models/model_ethusdt_long.pkl")
print("✅ AI TP Long:", round(model.predict_proba(x)[0][1] * 100, 2), "%")
