import joblib

model = joblib.load("models/model_ethusdt_long.pkl")
print("✅ Các feature trong model:")
for f in model.feature_name_:
    print("-", f)
