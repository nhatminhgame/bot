import ccxt

config = {
    "options": {"defaultType": "future"},
    "apiKey": "n4mcTebbbtavfNNw1zZpfnBdWWyrOMXPOblUeZwOsJwXoCcaZNpSo7R15BaNz5SA",
    "secret": "kbHxGAXfQhcPN6w9sNgT04G31XaY1Unjo4iIUoTxWnwv8clZZ0wSPVqv4bEoDVFO",

    "symbol": "ETH/USDT",
    "interval": "15m",
    "lookback": 250,

    "leverage": 4,
    "capital_percent": 0.10,

    "ai_threshold": 0.7,
    "rr_ratio": 1.5,
    "use_trailing_stop": True,

    "telegram_token": "7924335302:AAH-g6MYoRu_kjd-4oYpmWZPtya7D3dfRM8",
    "telegram_chat_id": "6653505845",
    "discord_webhook": "https://discord.com/api/webhooks/1376469492846297200/FPVrPB_JnsWddzzOQtEKXEm0se_4jiRVhvb-mmmacZMpNl-MbNTafMjwehPU8uZCo7ub",

    "scan_interval": 60,
    "loop_interval": 60,
    "risk_levels_allowed": ["LOW", "MEDIUM"],

    # ✅ Tên model đúng (không có .pkl)
    "model_name": "model_ethusdt"
}

# Kết nối Binance Futures
config["exchange"] = ccxt.binance({
    "apiKey": config["apiKey"],
    "secret": config["secret"],
    "enableRateLimit": True,
    "options": {"defaultType": "future"}
})
