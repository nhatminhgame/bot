import ta
import numpy as np
import pandas as pd

def get_all_indicators(df_15m: pd.DataFrame, df_1h: pd.DataFrame) -> pd.DataFrame:
    df = df_15m.copy()

    # ------------------ 15M chỉ báo gốc ------------------
    df['rsi'] = ta.momentum.rsi(df['close'])
    df['macd'] = ta.trend.macd(df['close'])
    df['macd_signal'] = ta.trend.macd_signal(df['close'])
    df['trend_macd'] = ta.trend.macd_diff(df['close'])
    df['adx'] = ta.trend.adx(df['high'], df['low'], df['close'])
    df['atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'])
    df['ema_fast'] = ta.trend.ema_indicator(df['close'], window=12)
    df['ema_slow'] = ta.trend.ema_indicator(df['close'], window=26)
    df['volatility_bbh'] = ta.volatility.bollinger_hband(df['close'])
    df['momentum_wr'] = ta.momentum.williams_r(df['high'], df['low'], df['close'])
    df['trend_kst'] = ta.trend.kst(df['close'])
    df['momentum_ao'] = ta.momentum.awesome_oscillator(df['high'], df['low'])
    df['trend_ichimoku_base'] = ta.trend.ichimoku_base_line(df['high'], df['low'])
    df['trend_adx'] = df['adx']

    # ------------------ Feature tự tạo từ 15M ------------------
    df['ema_distance'] = (df['close'] - df['ema_fast']) / df['ema_fast']
    df['macd_histogram'] = df['macd'] - df['macd_signal']
    df['atr_change'] = df['atr'].pct_change()
    df['wick_ratio'] = (df['high'] - df['low']) / (df['close'] - df['open']).replace(0, np.nan)
    df['price_change_3'] = df['close'].pct_change(3)
    df['price_change_10'] = df['close'].pct_change(10)
    df['ema_fast_slope'] = df['ema_fast'].diff()
    df['bb_pos'] = (df['close'] - df['volatility_bbh']) / df['volatility_bbh']
    df['volume_change'] = df['volume'].pct_change()
    df['rsi_slope'] = df['rsi'].diff()
    df['macd_cross'] = (df['macd'] > df['macd_signal']).astype(int)
    df['volatility_ratio'] = (df['volatility_bbh'] - ta.volatility.bollinger_lband(df['close'])) / df['close']

    # ------------------ Gắn chỉ báo khung 1H ------------------
    df_1h = df_1h.copy()
    df_1h['rsi_1h'] = ta.momentum.rsi(df_1h['close'])
    df_1h['ema_1h'] = ta.trend.ema_indicator(df_1h['close'], window=20)
    df_1h['macd_1h'] = ta.trend.macd(df_1h['close'])
    df_1h['macd_signal_1h'] = ta.trend.macd_signal(df_1h['close'])
    df_1h['volume_change_1h'] = df_1h['volume'].pct_change()

    # Lấy dòng 1H cuối cùng, gắn vào dòng 15M cuối cùng
    for col in ['rsi_1h', 'ema_1h', 'macd_1h', 'macd_signal_1h', 'volume_change_1h']:
        df[col] = df_1h[col].iloc[-1]

    df = df.dropna().reset_index(drop=True)
    return df
