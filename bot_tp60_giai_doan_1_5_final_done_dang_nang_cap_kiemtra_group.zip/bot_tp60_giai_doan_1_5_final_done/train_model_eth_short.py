# -*- coding: utf-8 -*-
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
import joblib

df = pd.read_csv("multi_coin_15m_1year.csv")
df_eth = df[df["symbol"] == "ETH/USDT"].copy()
df_eth = df_eth.dropna()

features = [
    'volume', 'volatility_bbm', 'volatility_bbh', 'volatility_bbl',
    'trend_macd', 'momentum_rsi', 'momentum_wr', 'trend_adx',
    'trend_ema_fast', 'trend_ema_slow', 'trend_ichimoku_base',
    'volatility_atr', 'momentum_ao', 'trend_kst'
]

X = df_eth[features]
y = df_eth["target_short"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

model = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.03)
model.fit(X_train, y_train)

y_pred = model.predict_proba(X_test)[:, 1]
auc = roc_auc_score(y_test, y_pred)
print(f"AUC SHORT model: {auc:.4f}")

joblib.dump(model, "model_eth_short.pkl")
print("? da luu model_eth_short.pkl")
