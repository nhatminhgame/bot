
#!/bin/bash
cd $(dirname "$0")

echo "🧠 Đang huấn luyện lại mô hình AI từ trade_log.csv..."
python3 label_and_train.py >> retrain_log.txt 2>&1

echo "🔁 Khởi động lại bot sau khi huấn luyện..."
pkill -f main.py
nohup python3 main.py >> bot_log.txt 2>&1 &
