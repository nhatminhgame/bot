import os
import joblib

def predict_prob(df, symbol="ETH/USDT", signal_type="long"):
    try:
        symbol_key = symbol.replace("/", "").lower()
        model_filename = f"models/model_{symbol_key}_{signal_type}.pkl"
        if not os.path.exists(model_filename):
            model_filename = f"models/final_tp_model_{signal_type}.pkl"  # fallback neu không có model theo coin

        model = joblib.load(model_filename)
        print("[AI] ✅ Model file được load:", model_filename)


        required_features = model.feature_name_
        missing = [f for f in required_features if f not in df.columns]
        if missing:
            raise ValueError(f"[❌ AI TP] Thiếu các feature đầu vào: {missing}")

        df_input = df[required_features]
        #print("[AI] ✅ Input features cuối cùng:")
        #print(df_input.dropna().tail(1).T)


        # ������ Debug giá trị input dòng cuối cùng
        #last_row = df_input.iloc[-1]
        #print(" [AI] Input features (last row):")
        #print(last_row)
        #print(" [AI] NaN check:")
        #print(last_row.isnull())

        # Dự đoán
        prob = model.predict_proba(df_input)[-1][1]  # dùng [-1] lay dòng cuoi
        print(f"[AI] ✅ Kết quả dự đoán AI TP: {prob * 100:.2f}%")
        return float(prob)

    except Exception as e:
        print(f"[AI] ❌ Lỗi khi dự đoán AI TP: {e}")
        return 0.0
