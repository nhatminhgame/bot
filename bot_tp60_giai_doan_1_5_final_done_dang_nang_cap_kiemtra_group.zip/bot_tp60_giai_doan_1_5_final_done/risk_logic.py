
def assess_risk(entry_score, tp_prob):
    if tp_prob >= 0.75:
        return "LOW"
    elif tp_prob >= 0.6:
        return "MEDIUM"
    else:
        return "HIGH"


def get_trade_allocation(ai_tp):
    if ai_tp >= 80:
        return 1.0  # 100% vốn tối đa
    elif ai_tp >= 70:
        return 0.8
    elif ai_tp >= 60:
        return 0.5
    else:
        return 0.3
