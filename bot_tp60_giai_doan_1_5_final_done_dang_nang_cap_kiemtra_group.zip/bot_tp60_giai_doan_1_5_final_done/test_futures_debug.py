import ccxt

api_key = 'n4mcTebbbtavfNNw1zZpfnBdWWyrOMXPO1lUeZwOsJwXoCcaZNpSo7R15BaNz5SA'
secret = 'kbHxGAXfQhcPN6w9sNgT04G31XaY1Unjo1iIUoTxWnwv8clZZ0wSPVqv4bEoDVFO'

binance = ccxt.binance({
    'apiKey': api_key,
    'secret': secret,
    'enableRateLimit': True,
    'options': {
        'defaultType': 'future'  # KHoNG duoC THIeU
    }
})

print("Endpoint Futures:", binance.urls['api']['fapi'])
