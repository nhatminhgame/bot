
def check_entry_groups_verbose(df):
    active_indicators = []
    group_triggered = None

    # Ví dụ: nhóm A = MACD + RSI, nhóm B = EMA + ADX, nhóm C = Ichimoku, v.v.
    if macd_signal(df) and rsi_signal(df):
        active_indicators += ["MACD", "RSI"]
        group_triggered = "A"
    elif ema_crossover(df) and adx_strong(df):
        active_indicators += ["EMA", "ADX"]
        group_triggered = "B"
    elif ichimoku_bullish(df):
        active_indicators += ["Ichimoku"]
        group_triggered = "C"
    elif bollinger_breakout(df):
        active_indicators += ["Bollinger"]
        group_triggered = "D"
    elif momentum_strong(df):
        active_indicators += ["Momentum"]
        group_triggered = "E"
    elif williams_oversold(df):
        active_indicators += ["Williams %R"]
        group_triggered = "F"
    elif macd_signal(df) and ema_crossover(df) and rsi_signal(df):
        active_indicators += ["MACD", "EMA", "RSI"]
        group_triggered = "G"

    return group_triggered, active_indicators

# Mock tín hiệu cho ví dụ (tùy bot thật sẽ thay bằng logic thật)
def macd_signal(df): return True if df["close"].iloc[-1] % 2 == 0 else False
def rsi_signal(df): return True
def ema_crossover(df): return True
def adx_strong(df): return True
def ichimoku_bullish(df): return True
def bollinger_breakout(df): return False
def momentum_strong(df): return True
def williams_oversold(df): return True
