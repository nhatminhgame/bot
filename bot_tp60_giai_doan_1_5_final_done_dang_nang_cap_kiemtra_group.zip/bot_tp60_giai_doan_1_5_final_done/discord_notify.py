
import requests

DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1376469492846297200/FPVrPB_JnsWddzzOQtEKXEm0se_4jiRVhvb-mmmacZMpNl-MbNTafMjwehPU8uZCo7ub"

def send_discord(message: str):
    try:
        data = {"content": message}
        response = requests.post(DISCORD_WEBHOOK_URL, json=data)
        if response.status_code != 204:
            print(f"[Discord] ❌ Loi: {response.status_code} - {response.text}")
        else:
            print(f"[Discord] ✅ Da gui: {message}")
    except Exception as e:
        print(f"[Discord] ❌ Loi gui Discord: {e}")
