
def check_entry_group_f(df, ai_tp=None, trend=None):
    """
    Group F – Early Entry / Pre-Breakout:
    Nhóm độc lập nhằm phát hiện khả năng breakout sớm và vào lệnh limit
    """
    score = 0.0
    debug = []

    # RSI breakout 50 lần đầu
    if df["rsi"].iloc[-1] > 50 and df["rsi"].iloc[-2] < 50:
        score += 0.3
        debug.append("RSI breakout 50")

    # Nến xanh thân lớn (bullish marubozu)
    body = abs(df["close"].iloc[-1] - df["open"].iloc[-1])
    candle_range = df["high"].iloc[-1] - df["low"].iloc[-1]
    if body > 0.6 * candle_range and df["close"].iloc[-1] > df["open"].iloc[-1]:
        score += 0.2
        debug.append("Bullish candle")

    # Volume tăng
    if df["volume"].iloc[-1] > df["volume"].rolling(20).mean().iloc[-1]:
        score += 0.2
        debug.append("Volume > MA20")

    # BB squeeze và ép biên
    if "bb_width" in df.columns and "bb_upper" in df.columns:
        if df["bb_width"].iloc[-1] < df["bb_width"].rolling(30).mean().iloc[-1]:
            if df["close"].iloc[-1] > df["bb_upper"].iloc[-2]:
                score += 0.2
                debug.append("BB squeeze + close > BB upper")

    # EMA20 hướng lên
    if "ema20" in df.columns:
        ema_slope = df["ema20"].iloc[-1] - df["ema20"].iloc[-5]
        if ema_slope > 0:
            score += 0.1
            debug.append("EMA20 rising")

    # AI trend dự báo tăng
    if trend and trend.lower() == "up":
        score += 0.2
        debug.append("AI trend = UP")

    return score, debug
