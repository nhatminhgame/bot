
# bot_main_v2_stage6.py - Full version Stage 6: AI TP logic, trailing, AI Entry, reasons
import time
import pandas as pd
import joblib
from datetime import datetime
import exit_logic  # thêm kiểm tra smart exit
import hold_manager  # thêm kiểm tra AI TP giảm
import trailing  # quản lý trailing sau TP1
from config import config
from discord_notify import send_discord as send_telegram
from ai_predict import predict_prob
from order_manager import OrderManager
from utils import get_ohlcv_binance, get_trade_size
from indicators import get_all_indicators
from breakout_logic import (
    detect_consolidation_zone,
    confirm_breakout,
    generate_breakout_trade,
    validate_trade_with_ai_and_risk,
)
from log_trade import log_trade

# Load AI trend
try:
    trend_model = joblib.load("models/model_trend_predictor.pkl")
    trend_map = {0: "DOWN", 1: "FLAT", 2: "UP"}

    def predict_trend(df_latest):
        try:
            indicators = get_all_indicators(df_latest).iloc[[-1]].copy()
            indicators = indicators[trend_model.feature_name_]
            pred = trend_model.predict(indicators)[0]
            return trend_map[pred]
        except Exception as e:
            print(f"[TrendAI] ? Trend prediction error: {e}")
            return "UNKNOWN"

except:
    def predict_trend(df_latest):
        return "UNKNOWN"

def main():
    send_telegram("?? Bot khoi dong )")
    order_manager = OrderManager(config)
    last_trade_time = time.time()
    last_notify_time = time.time()
    notify_interval = 15 * 60

    while True:
        # ✅ Smart Exit: đóng lệnh nếu AI xấu
        if position is not None and exit_logic.smart_exit_check(position, df_recent, model_long):
            order_manager.close_position(position, reason='Smart Exit')
            position = None

        # ✅ Hold Manager: đóng nếu AI TP < 50%
        if position is not None and hold_manager.monitor_hold_position(position, df_recent, model_long):
            order_manager.close_position(position, reason='AI TP giảm')
            position = None

        # ✅ Trailing Stop sau TP1
        if position is not None and reached_tp1(df_recent, position):
            trailing.update_trailing_stop(position, df_recent)

        try:
            df = get_ohlcv_binance(config["symbol"], config["interval"], config["lookback"])
            indicators = get_all_indicators(df)
            print("[DEBUG] Indicator columns:", indicators.columns.tolist())

            # Kiem tra chi bao ADX co ton tai va khong bi NaN
            if 'adx' not in indicators.columns or indicators['adx'].isnull().all():
                send_telegram("[Bot] Loi: khong co chi bao ADX (du lieu chua du)")
                time.sleep(60)
                continue


            X = indicators.iloc[[-1]].copy()

            prob_long = predict_prob(X.copy(), config["symbol"], signal_type="long")
            prob_short = predict_prob(X.copy(), config["symbol"], signal_type="short")

            print(f"AI LONG: {prob_long:.2f}, SHORT: {prob_short:.2f}")

            signal = None
            prob = 0
            if prob_long > config['ai_threshold'] and prob_long > prob_short:
                signal = 'long'
                prob = prob_long
            elif prob_short > config['ai_threshold'] and prob_short > prob_long:
                signal = 'short'
                prob = prob_short

            trend = predict_trend(df)
            if signal and ((signal == "long" and trend == "DOWN") or (signal == "short" and trend == "UP") or (trend == "FLAT" and prob < 0.7)):
                send_telegram(f"[TrendAI] ? Bo lenh {signal.upper()} do trend: {trend}, AI TP = {round(prob*100,2)}%")
                signal = None

            # Risk + Breakout check
            zone = detect_consolidation_zone(df, window=7, threshold=0.03)
            breakout_type = None
            if zone:
                breakout_type = confirm_breakout(df[-1:], zone, volume_multiplier=1.2)

            risk_level = order_manager.evaluate_risk(indicators)
            signal_allowed = False
            if prob >= 0.7:
                signal_allowed = True
            elif prob >= 0.6 and (risk_level in config["risk_levels_allowed"] or breakout_type):
                signal_allowed = True

            if signal and signal_allowed:
                if not order_manager.has_open_position():
                    size = get_trade_size(df, config)
                    try:
                        entry_model = joblib.load("models/model_entry_regressor.pkl")
                        X_entry = indicators.iloc[[-1]][['rsi', 'atr', 'macd', 'trend_ema_fast', 'trend_ema_slow']]
                        X_entry['ema_diff'] = X_entry['trend_ema_fast'] - X_entry['trend_ema_slow']
                        X_entry = X_entry[['rsi', 'atr', 'macd', 'ema_diff']]
                        print("[AI Entry] Input:", X_entry.iloc[0].to_dict())
                        entry_offset = entry_model.predict(X_entry)[0]
                        current_price = df['close'].iloc[-1]
                        entry_price = current_price * (1 + entry_offset) if signal == "long" else current_price * (1 - entry_offset)
                        send_telegram(f"[AI Entry] Entry: {round(entry_price, 2)} (offset {round(entry_offset*100,2)}%)")
                    except Exception as e:
                        send_telegram(f"? Loi AI Entry: {e}")
                        continue

                    order_manager.open_order(signal, size, df, custom_entry=entry_price)

                    log_trade({
                        "timestamp": datetime.now().isoformat(),
                        "symbol": config['symbol'],
                        "side": signal,
                        "entry_price": round(entry_price, 2),
                        "size": size,
                        "ai_tp": round(prob, 4),
                        "ai_entry_offset": round(entry_offset, 4),
                        "trend": trend,
                        "risk_level": risk_level
                    })

                    send_telegram(f"[Bot] ?? Vao lenh {signal.upper()} | TP: {round(prob*100,2)}% | Entry: {round(entry_price,2)}")
                    last_trade_time = time.time()
                else:
                    print("?? Da co vi the.")

            else:
                print("? Chua du xac suat de vao lenh.")

            order_manager.manage_positions(df, indicators, prob)

            if (time.time() - last_trade_time > notify_interval and
                time.time() - last_notify_time > notify_interval and
                config['symbol'] == "ETH/USDT"):

                reasons = ["? 15 phut chua co lenh moi cho ETH/USDT:"]

                if zone:
                    reasons.append("? Phat hien vung tich luy")
                else:
                    reasons.append("? Khong co vung tich luy ro")

                if zone and breakout_type:
                    reasons.append(f"? Breakout xac nhan: {breakout_type.upper()}")
                else:
                    reasons.append("? Chua co breakout hoac chua xac nhan volume")

                prob_display = max(prob_long, prob_short)
                signal_type_str = "LONG" if prob_long >= prob_short else "SHORT"
                
                if prob >= 0.7:
                    reasons.append(f"? AI TP ({signal_type_str}) = {prob_display * 100:.1f}% (= 70%)")
                elif prob >= 0.6:
                    reasons.append(f"?? AI TP ({signal_type_str}) = {prob_display * 100:.1f}% (duoc phep neu risk tot hoac breakout)")
                else:
                    reasons.append(f"? AI TP ({signal_type_str}) thap = {prob_display * 100:.1f}%")

                reasons.append(f"? Trend hien tai: {trend}")

                if risk_level:
                    if risk_level in config['risk_levels_allowed']:
                        reasons.append(f"? RISK level = {risk_level}")
                    else:
                        reasons.append(f"? RISK qua cao = {risk_level}")
                else:
                    reasons.append("? RISK level chua xac dinh")

                reasons.append("? Bot khong vao lenh do chua du dieu kien.")
                send_telegram("\n".join(reasons))
                last_notify_time = time.time()

            time.sleep(config["loop_interval"])

        except Exception as e:
            send_telegram(f"[Bot] ? Loi: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()
