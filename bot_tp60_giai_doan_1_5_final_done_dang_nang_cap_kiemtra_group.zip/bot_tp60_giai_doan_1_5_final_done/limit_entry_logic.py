
# limit_entry_logic.py - Chiến lược LIMIT Entry sớm an toàn (V3)
def get_safe_limit_price(current_price, trend, strategy='default'):
    '''
    Tinh gia LIMIT an toan dua tren trend va chien luoc
    '''
    if trend == 'UP':
        if strategy == 'spring':
            return round(current_price * 0.9975, 2)  # LIMIT thap hon chut
        return round(current_price * 0.9985, 2)      # LIMIT cach ~0.15%
    elif trend == 'DOWN':
        if strategy == 'spring':
            return round(current_price * 1.0025, 2)
        return round(current_price * 1.0015, 2)
    return round(current_price, 2)


def get_dca_limit_prices(current_price, atr, side, num_orders=3):
    """
    Trả về danh sách giá LIMIT DCA giãn cách theo ATR (>= 0.5%)
    """
    dca_prices = []
    min_step = max(atr * 0.5, current_price * 0.005)  # tối thiểu 0.5%
    for i in range(num_orders):
        offset = min_step * (i + 1)
        if side == "long":
            price = round(current_price - offset, 2)
        else:
            price = round(current_price + offset, 2)
        dca_prices.append(price)
    return dca_prices
