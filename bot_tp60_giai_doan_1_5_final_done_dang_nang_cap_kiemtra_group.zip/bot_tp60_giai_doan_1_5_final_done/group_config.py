
group_weights = {
    "GROUP_A": 0.7,
    "GROUP_B": 1.0,
    "GROUP_C": 0.8,
    "GROUP_D": 0.6,
    "GROUP_E": 0.5,
}

group_winrate_10d = {
    "GROUP_A": 0.53,
    "GROUP_B": 0.66,
    "GROUP_C": 0.47,
    "GROUP_D": 0.42,
    "GROUP_E": 0.59,
}

suspended_groups = [g for g, w in group_winrate_10d.items() if w < 0.45]
